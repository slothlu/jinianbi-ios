/* Zoom lock v2: native gesture guards + early frame protection, without blocking normal scrolling. */
(function install(win) {
 'use strict';
 var doc;try{doc=win.document;}catch(e){return;}
 if(win.__SX_PAGE_GUARD_VERSION__===2)return;
 if(win.__SX_SET_PAGE_LOCK__)try{win.__SX_SET_PAGE_LOCK__(false);}catch(e){}
 win.__SX_PAGE_GUARD__=true;win.__SX_PAGE_GUARD_VERSION__=2;
 var locked=false,targetScale=null,originals=new Map(),enforced=new Map(),created=new Set(),fonts=new Map(),roots=new Map(),frames=new WeakSet(),scheduled=false;
 function editable(el){return el&&(el.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));}
 function saveStyle(map,el,property){if(!map.has(el))map.set(el,[el.style.getPropertyValue(property),el.style.getPropertyPriority(property)]);}
 function setStyle(el,key,value){if(el.style.getPropertyValue(key)!==value||el.style.getPropertyPriority(key)!=='important')el.style.setProperty(key,value,'important');}
 function protectInput(el){if(!locked||!el||!el.style)return;var size=parseFloat(win.getComputedStyle(el).fontSize);if(size<16){if(fonts.has(el)&&el.style.getPropertyValue('font-size')!=='16px')fonts.set(el,[el.style.getPropertyValue('font-size'),el.style.getPropertyPriority('font-size')]);saveStyle(fonts,el,'font-size');setStyle(el,'font-size','16px');}}
 function frameLock(frame){try{var child=frame.contentWindow;if(child)child.postMessage({type:'__SX_PAGE_LOCK_SYNC_V2',enabled:locked},'*');if(child&&child.document){install(child);child.__SX_SET_PAGE_LOCK__(locked);}}catch(e){/* Cross-origin frames are handled by the native WebView gesture lock. */}}
 function protect(){
  if(!locked||!doc.documentElement)return;
  var root=doc.documentElement;
  if(!roots.has(root))roots.set(root,['touch-action','-webkit-text-size-adjust','text-size-adjust'].map(function(k){return [k,root.style.getPropertyValue(k),root.style.getPropertyPriority(k)];}));
  setStyle(root,'touch-action','pan-x pan-y');setStyle(root,'-webkit-text-size-adjust','100%');setStyle(root,'text-size-adjust','100%');
  var metas=Array.prototype.slice.call(doc.querySelectorAll('meta[name="viewport" i]'));
  if(metas.some(function(m){return !created.has(m);})){metas=metas.filter(function(m){if(created.has(m)){m.remove();created.delete(m);originals.delete(m);enforced.delete(m);return false;}return true;});}
  if(!metas.length){var meta=doc.createElement('meta');meta.name='viewport';created.add(meta);(doc.head||root).appendChild(meta);metas=[meta];}
  metas.forEach(function(meta){
   var actual=meta.getAttribute('content');if(!originals.has(meta)||enforced.has(meta)&&actual!==enforced.get(meta))originals.set(meta,actual);
   var content=(originals.get(meta)||'').split(/[,;]/).filter(function(s){return !/^\s*(user-scalable|minimum-scale|maximum-scale)\s*=/i.test(s);}).filter(Boolean).join(',');
   if(targetScale!==null){content=content.split(',').filter(function(s){return !/^\s*initial-scale\s*=/i.test(s);}).filter(Boolean).join(',');content+=(content?',':'')+'initial-scale='+targetScale+',minimum-scale='+targetScale+',maximum-scale='+targetScale;}
   content+=(content?',':'')+'user-scalable=no';if(actual!==content)meta.setAttribute('content',content);enforced.set(meta,content);
  });
  doc.querySelectorAll('input,textarea,select').forEach(protectInput);
  doc.querySelectorAll('iframe,frame').forEach(function(frame){if(!frames.has(frame)){frames.add(frame);frame.addEventListener('load',function(){frameLock(frame);});}try{if(!frame.contentWindow||frame.contentWindow.__SX_PAGE_LOCKED__!==locked)frameLock(frame);}catch(e){frameLock(frame);}});
 }
 function queueProtect(){if(!locked||scheduled)return;scheduled=true;win.requestAnimationFrame(function(){scheduled=false;protect();});}
 function settle(){if(!locked)return;win.requestAnimationFrame(function(){win.requestAnimationFrame(function(){if(!locked)return;var scale=win.visualViewport&&win.visualViewport.scale;if(targetScale===null&&Number.isFinite(scale)&&scale>0)targetScale=scale;protect();});});}
 win.__SX_SET_PAGE_LOCK__=function(enabled){
  var previous=locked;locked=enabled===true;win.__SX_PAGE_LOCKED__=locked;
  if(locked){if(!previous){targetScale=null;if(doc.readyState!=='loading'){var scale=win.visualViewport&&win.visualViewport.scale;if(Number.isFinite(scale)&&scale>0)targetScale=scale;}}protect();if(targetScale===null&&doc.readyState!=='loading')settle();}
  else{
   originals.forEach(function(value,meta){if(meta.getAttribute('content')!==enforced.get(meta))return;if(value===null)meta.removeAttribute('content');else meta.setAttribute('content',value);});originals.clear();enforced.clear();
   created.forEach(function(meta){meta.remove();});created.clear();
   fonts.forEach(function(value,el){if(el.style.getPropertyValue('font-size')!=='16px'||el.style.getPropertyPriority('font-size')!=='important')return;if(value[0])el.style.setProperty('font-size',value[0],value[1]);else el.style.removeProperty('font-size');});fonts.clear();
   roots.forEach(function(values,el){values.forEach(function(v){if(v[1])el.style.setProperty(v[0],v[1],v[2]);else el.style.removeProperty(v[0]);});});roots.clear();targetScale=null;
   doc.querySelectorAll('iframe,frame').forEach(frameLock);
  }
 };
 new MutationObserver(queueProtect).observe(doc,{subtree:true,childList:true,attributes:true,attributeFilter:['content','style','class','name']});
 function touch(e){if(!locked)return;if(editable(e.target))protectInput(e.target);if(e.touches&&e.touches.length>1&&e.cancelable)e.preventDefault();}
 doc.addEventListener('touchstart',touch,{passive:false,capture:true});doc.addEventListener('touchmove',touch,{passive:false,capture:true});
 doc.addEventListener('pointerdown',function(e){if(locked&&editable(e.target))protectInput(e.target);},true);
 ['gesturestart','gesturechange','gestureend'].forEach(function(name){doc.addEventListener(name,function(e){if(locked&&e.cancelable)e.preventDefault();},{passive:false,capture:true});});
 doc.addEventListener('dblclick',function(e){if(locked&&!editable(e.target)&&e.cancelable)e.preventDefault();},true);
 doc.addEventListener('focusin',function(e){if(locked){protectInput(e.target);protect();}},true);
 doc.addEventListener('DOMContentLoaded',function(){if(locked){protect();settle();}});
 win.addEventListener('message',function(e){if(win.parent!==win && e.source===win.parent && e.data && e.data.type==='__SX_PAGE_LOCK_SYNC_V2' && typeof e.data.enabled==='boolean')win.__SX_SET_PAGE_LOCK__(e.data.enabled);});
 win.addEventListener('load',function(){if(locked){protect();settle();}});win.addEventListener('pageshow',function(){if(locked){protect();settle();}});
})(window);
