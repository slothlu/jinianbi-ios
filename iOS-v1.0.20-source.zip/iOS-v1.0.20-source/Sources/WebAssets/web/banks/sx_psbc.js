/**
 * 路面纪念钞币科技 · 中国邮政储蓄银行（PSBC）适配器
 * element-ui 增强型：
 *   ① 基础字段 + 证件类型 + 原生省市区 select
 *   ② 地区 el-cascader（省/市/区）逐级选择
 *   ③ 网点 el-select 两级选择（专用下拉，失败回退 BranchFinder / 直写）
 *   ④ 兑换日期、数量（专用数量输入框）、协议勾选
 *   ⑤ 提交按钮文案兜底含“下一步”
 */
(function () {
  "use strict";
  const C = window.__SX_COMMON__;

  const adapter = {
    id: "PSBC",
    detect: () => {
      const host = location.hostname || "";
      const path = location.pathname || "";
      return host.includes("psbc") || host.includes("postal") || path.includes("邮政") || path.includes("psbc");
    },

    async waitForOpen() { },

    getSelectorMap: () => ({
      fullName: 'input[name*="name"],input[id*="name"],input[placeholder*="姓名"]',
      idType: 'select[name*="certType"],select[id*="certType"],select[name*="idType"],select[id*="idType"]',
      idNumber:
        'input[name*="idNo"],input[id*="idNo"],input[name*="certNo"],input[id*="certNo"],input[placeholder*="证件号码"]',
      mobile:
        'input[name*="mobile"],input[id*="mobile"],input[name*="phone"],input[id*="phone"],input[placeholder*="手机号"]',
      address:
        'textarea[name*="address"],textarea[id*="address"],input[name*="address"],input[id*="address"],textarea[placeholder*="地址"],input[placeholder*="地址"]',
      province: 'select[name*="province"],select[id*="province"]',
      city: 'select[name*="city"],select[id*="city"]',
      district: 'select[name*="district"],select[id*="district"],select[name*="county"],select[id*="county"]',
      branch: 'input[name*="branch"],input[id*="branch"],input[placeholder*="网点"],.el-cascader input.el-input__inner',
      quantity: 'input[name*="count"],input[id*="count"],input[name*="amount"],input[id*="amount"],input[placeholder*="数量"],input[type="number"]'
    }),

    findInputByKeywords(key) {
      const kw = {
        fullName: ["姓名", "客户姓名", "兑换人"],
        idNumber: ["证件号码", "证件号", "身份证"],
        mobile: ["手机号", "手机号码", "联系电话"],
        address: ["联系地址", "详细地址", "通讯地址"],
        branch: ["网点", "兑换网点", "选择网点"]
      };
      const words = kw[key];
      if (!words) return null;
      for (const el of document.querySelectorAll("input, textarea")) {
        if (!C.isVisible(el) || el.readOnly) continue;
        const hay = C.esc(
          (el.getAttribute("placeholder") || "") + "|" + (el.getAttribute("aria-label") || "") + "|" +
          (el.name || "") + "|" + (el.id || "") + "|" + (el.closest("label") ? C.esc(el.closest("label").textContent) : "")
        );
        if (words.some((w) => hay.indexOf(C.esc(w)) >= 0)) return el;
      }
      return null;
    },

    // 数量输入框：placeholder/name/id 关键词 + number/max 兜底
    findQuantityInput() {
      return C.findQuantityInput();
    },

    // 地区 el-cascader（省/市/区，取路径前 3 段）
    async fillPsbcRegionCascader(person) {
      const parts = C.resolveBranchParts(person);
      if (!parts.length) return { success: false, message: "无地区信息" };
      const BF = window.__branchFinder__;
      if (!BF) return { success: false, message: "网点引擎未加载" };
      const regionParts = parts.slice(0, 3);
      if (!regionParts.length) return { success: false, message: "无地区段" };
      const cascInput = BF.findCascaderInput(/地区|所在|省市|网点/);
      if (!cascInput) { console.log("[PSBC] 未找到地区级联框，可能为原生 select"); return { success: false, message: "无级联框" }; }
      const r = await BF.selectCascaderValues(cascInput, regionParts);
      console.log("[PSBC] 地区级联结果:", r);
      return r;
    },

    // 网点 el-select 专用下拉（评分去后缀含邮储银行）
    async selectPsbcBranchFromDropdown(branchName) {
      if (!branchName) return { success: false, message: "网点名为空" };
      const BF = window.__branchFinder__;
      if (!BF) return { success: false, message: "网点引擎未加载" };

      const findBranchSelectInput = () => {
        const formItems = Array.from(document.querySelectorAll(".el-form-item"));
        const item = formItems.find((fi) => {
          const label = fi.querySelector(".el-form-item__label");
          const t = (label && label.textContent || "").trim();
          return /网点|兑换网点|预约网点/.test(t);
        });
        let input = null;
        if (item) input = item.querySelector(".el-select input.el-input__inner, input.el-input__inner");
        if (!input) {
          const all = Array.from(document.querySelectorAll("input.el-input__inner"));
          input = all.find((i) => /网点|兑换网点|预约网点/.test((i.placeholder || "").trim())) || null;
        }
        return input;
      };

      const input = findBranchSelectInput();
      if (!input) return { success: false, message: "未找到网点选择框" };
      try { input.focus(); } catch (e) { /* ignore */ }
      input.click();
      await BF.delay(200);
      let menu = BF.getVisibleElSelectDropdown();
      let n = 0;
      while (!menu && n < 10) { await BF.delay(150); menu = BF.getVisibleElSelectDropdown(); n++; }
      if (!menu) { await BF.forceOpenDropdown(input); await BF.delay(150); menu = BF.getVisibleElSelectDropdown(); }
      if (!menu) return { success: false, message: "未检测到网点下拉" };

      const items = BF._visibleItems(menu, ".el-select-dropdown__item, li[role='option'], li");
      if (!items.length) return { success: false, message: "网点下拉无选项" };

      const norm = (s) => String(s || "").replace(/邮储银行|中国邮政储蓄银行|省|市|区|县|分行|支行|营业部|营业所|营业室|网点/g, "").trim();
      const nb = norm(branchName);
      let best = null, bestScore = 0;
      items.forEach((it) => {
        const t = (it.textContent || "").trim();
        if (!t) return;
        let s = 0;
        if (t === branchName) s = 1000;
        else if (t.includes(branchName)) s = 900;
        else if (branchName.includes(t)) s = 800;
        else {
          const nt = norm(t);
          if (nt === nb) s = 950;
          else if (nt && nb && nt.includes(nb)) s = 700;
          else if (nt && nb && nb.includes(nt)) s = 650;
        }
        if (s > bestScore) { bestScore = s; best = it; }
      });
      if (!best) return { success: false, message: "未匹配到网点" };

      best.scrollIntoView({ block: "center" });
      await BF.delay(60);
      const cr = await BF._clickItem(best);
      if (!cr.success) return { success: false, message: cr.message };
      await BF.delay(150);
      return { success: true, text: (best.textContent || "").trim() };
    },

    // 网点两级选择：专用下拉 → BranchFinder → 直写
    async fillBranch(person) {
      const parts = C.resolveBranchParts(person);
      const branchName = person.branch || (parts.length ? parts[parts.length - 1] : "");
      const fullPath = parts.join("/");
      if (!branchName) return { success: false, message: "未提供网点" };

      const r1 = await this.selectPsbcBranchFromDropdown(branchName);
      if (r1.success) { console.log("[PSBC] 网点选择成功:", r1.text); return r1; }
      console.warn("[PSBC] 网点下拉失败，尝试 BranchFinder:", r1.message);

      if (window.__branchFinder__ && fullPath) {
        const r2 = await window.__branchFinder__.autoFillBranch(fullPath, { enableLog: false });
        if (r2 && r2.success) return r2;
        console.warn("[PSBC] BranchFinder 失败:", r2 && r2.message);
      }

      const sel = C.safeQ(this.getSelectorMap().branch);
      if (sel) { C.fillValue(sel, fullPath); return { success: true, message: "直接写入网点" }; }
      return { success: false, message: "网点选择失败" };
    },

    async fillForm(person = {}) {
      person = C.normalizePerson(person);
      const selMap = this.getSelectorMap();
      const smart = window.__SX_SMART_FIND__;
      const set = (key, val) => {
        if (val == null || val === "") return;
        let el = smart ? smart(key) : null;
        if (!el && key === "quantity") el = C.findQuantityInput();
        if (!el && selMap[key]) el = C.safeQ(selMap[key]);
        if (!el && this.findInputByKeywords) el = this.findInputByKeywords(key);
        if (el) C.fillValue(el, val);
        else console.warn("[PSBC] 未找到", key);
      };

      set("fullName", person.fullName);
      set("idNumber", person.idNumber);
      set("mobile", person.mobile);
      set("address", C.fullAddress(person));

      const idType = (smart && smart("idType")) || C.safeQ(selMap.idType);
      if (idType) C.selectIdType(idType);

      // ① 原生省/市/区 select（若存在）
      C.fillRegionSelects(person, selMap);
      // ② 地区 el-cascader（省/市/区）
      await this.fillPsbcRegionCascader(person);
      // ③ 网点 el-select 两级选择
      await this.fillBranch(person);

      // 兑换日期
      const date = C.normalizeExchangeDate(person.exchangeTime);
      const dateEl = C.findExchangeDateInput();
      if (date && dateEl) {
        C.fillValue(dateEl, date);
        console.log("[PSBC] 兑换日期填写成功:", date);
      } else if (person.exchangeTime) {
        console.warn("[PSBC] 未找到兑换日期输入框");
      }

      // 数量（专用数量输入框）
      if (person.quantity) {
        const q = this.findQuantityInput();
        if (q) { C.fillValue(q, person.quantity); console.log("[PSBC] 预约数量填写成功:", person.quantity); }
        else console.warn("[PSBC] 未找到数量输入框");
      }

      C.autoCheckAgreementCheckboxes();
      console.log("[PSBC] 表单填写完成");
      return { ok: true, bank: "PSBC" };
    },

    async submit() {
      const btn = C.safeQ('button[type="submit"], input[type="submit"], .el-button--primary, .submit, .btn-submit');
      if (btn && !btn.disabled) {
        btn.click();
        console.log("[PSBC] 提交按钮已点击");
        return true;
      }
      // 文案兜底：含“下一步”等
      const words = ["提交", "确认", "下一步", "预约", "完成"];
      const fallback = C.findButtonByText(words);
      if (fallback && !fallback.disabled) {
        fallback.click();
        console.log("[PSBC] 提交按钮（文案匹配）已点击");
        return true;
      }
      console.warn("[PSBC] 未找到提交按钮");
      return false;
    },

    async verifyResult() {
      return C.reservationSucceeded();
    }
  };

  window.shuixian.register(adapter);
})();
