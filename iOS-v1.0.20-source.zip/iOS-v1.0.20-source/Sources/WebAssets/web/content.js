/* content.js — App 版全自动编排（安卓 / iOS 共用）
 * 依赖注入顺序：bridge.js(bridge_ios.js) → BankMatch → sx_common → date_fill →
 *               sx_branch_finder → 5家适配器 → test_bridge → 本文件
 * 能力：银行识别 → 人员一键全自动（填表+日期兜底+验证码自动识别+自动提交）
 *      浮窗（可拖动/公告卖卡/设置入口）· 验证码变化自动监听 · SPA 路由重挂载
 * 与电脑端插件版的差异：无卡密门禁（App 原生已做）、OCR 走 App 原生链路、
 *      人员读 __SX_PERSONS_JSON__ / chrome.storage(userSettings)、支持手机 touch 拖动
 */
(function () {
  if (window.__SX_APP_CONTENT__) return;
  window.__SX_APP_CONTENT__ = true;
  if (!window.__SX_APP__) return; // 仅独立 App 内生效，避免误注入浏览器

  var C = window.__SX_COMMON__ || {};
  var floatingWindow = null;
  var floatMinimized = false;
  var isDragging = false;
  var dragOffset = { x: 0, y: 0 };
  var personsData = [];
  var captchaObserver = null;
  var lastCaptchaSignature = "";
  var captchaObserverPrimed = false;
  var captchaLoadTarget = null;
  var captchaLoadHandler = null;
  var _ocrSeq = 0;
  var _ocrWaiters = {};

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function log(m) { try { console.log("[SX App] " + m); } catch (e) {} }
  function warn(m) { try { console.warn("[SX App] " + m); } catch (e) {} }

  function toast(msg, kind) {
    kind = kind || "info";
    try {
      var box = document.querySelector(".sx-app-toast-container");
      if (!box) {
        box = document.createElement("div");
        box.className = "sx-app-toast-container";
        box.style.cssText = "position:fixed;top:60px;left:50%;transform:translateX(-50%);z-index:9999999;display:flex;flex-direction:column;align-items:center;gap:6px;pointer-events:none;";
        (document.body || document.documentElement).appendChild(box);
      }
      var t = document.createElement("div");
      t.className = "sx-app-toast-item";
      t.textContent = msg;
      t.style.cssText =
        "max-width:80vw;padding:10px 16px;border-radius:8px;font-size:13px;color:#fff;" +
        "background:" + (kind === "success" ? "linear-gradient(135deg,#4CAF50,#2E7D32)" :
          kind === "warning" ? "linear-gradient(135deg,#FF9800,#F57C00)" :
            "linear-gradient(135deg,#2563eb,#1e40af)") + ";" +
        "box-shadow:0 4px 12px rgba(0,0,0,.18);opacity:0;transition:opacity .25s ease,transform .25s ease;";
      box.appendChild(t);
      requestAnimationFrame(function () { t.style.opacity = "1"; });
      setTimeout(function () {
        t.style.opacity = "0";
        setTimeout(function () { try { t.remove(); } catch (e) {} }, 250);
      }, 3000);
    } catch (e) { /* 兜底：忽略 */ }
  }

  function getOptions() {
    return new Promise(function (resolve) {
      chrome.storage.local.get({autoOcr:true,autoSubmit:true,pageLocked:true}, function (v) {
        resolve({autoOcr:v.autoOcr !== false,autoSubmit:v.autoSubmit !== false,pageLocked:v.pageLocked !== false});
      });
    });
  }
  function detectAdapter() {
    var bank = window.shuixian && window.shuixian.detect();
    if (bank) return bank;
    var smart = window.__SX_SMART_FIND__;
    if (!smart || !smart('fullName') || !(smart('idNumber') || smart('mobile'))) return null;
    return {id:'GENERIC',fillForm:genericFillForm,submit:function(){return C.defaultSubmit && C.defaultSubmit();}};
  }
  async function genericFillForm(p) {
    var smart = window.__SX_SMART_FIND__;
    [['fullName',p.fullName],['idNumber',p.idNumber],['mobile',p.mobile],['address',p.address],['quantity',p.quantity]].forEach(function (pair) {
      var el = pair[1] && smart(pair[0]); if (el) C.fillValue(el,pair[1]);
    });
    var idType = smart('idType'); if (idType && C.selectIdType) C.selectIdType(idType);
    if (C.fillRegionSelects) await C.fillRegionSelects(p,{});
    var date = C.normalizeExchangeDate && C.normalizeExchangeDate(p.exchangeTime);
    var dateEl = C.findExchangeDateInput && C.findExchangeDateInput();
    if (date && dateEl) C.fillValue(dateEl,date);
  }

  /* ============ 人员读取 ============ */
  function normalizePersons(raw) {
    try {
      var d = typeof raw === "string" ? JSON.parse(raw) : raw;
      if (Array.isArray(d)) return d;
      if (d && typeof d === "object" && d.name) return [d];
    } catch (e) {}
    return [];
  }
  function loadPersons() {
    return new Promise(function (resolve) {
      try {
        // iOS：注入时同步携带
        if (window.__SX_PERSONS_JSON__ !== undefined) {
          resolve(normalizePersons(window.__SX_PERSONS_JSON__));
          return;
        }
        // 安卓：bridge.js 将 userSettings 桥接到 AndroidBridge.getPersons()
        if (window.chrome && window.chrome.storage && window.chrome.storage.local) {
          chrome.storage.local.get(["userSettings"], function (r) {
            var raw = (r && r.userSettings) || null;
            if (!raw && r && r.persons) raw = r.persons; // 兼容
            resolve(normalizePersons(raw));
          });
          return;
        }
        resolve([]);
      } catch (e) { resolve([]); }
    });
  }

  /* 人员 → 适配器入参（适配器用 fullName/idNumber/mobile；date_fill 用 exchangeTime） */
  function toAdapterPerson(p) {
    if (!p) return {};
    var idn = p.id_card || p.idcard || p.idNumber || "";
    var dt = p.ex_date || p.exchangeTime || "";
    return {
      fullName: p.name || p.fullName || "",
      name: p.name || p.fullName || "",
      remark: p.remark || "",
      mobile: p.phone || p.mobile || "",
      phone: p.phone || p.mobile || "",
      idNumber: idn,
      id_card: idn,
      idcard: idn,
      idType: p.idType || "身份证",
      province: p.province || "",
      city: p.city || "",
      district: p.district || "",
      branch: p.branch || "",
      branchPath: p.branchPath || [p.province,p.city,p.district,p.branch].filter(Boolean).join("/"),
      address: p.address || "",
      exchangeTime: dt,
      exchangeDate: dt,
      ex_date: dt,
      quantity: p.quantity || ""
    };
  }

  /* ============ 银行识别 ============ */
  function isSupportedBankPage() {
    try {
      var sx = window.shuixian;
      return !!detectAdapter();
    } catch (e) { return false; }
  }

  /* ============ 验证码自动监听（变化自动重识别） ============ */
  function findCaptchaImage() {
    // 1) el-form-item / label 含 验证码/图形码/校验码/附加码
    var items = Array.prototype.slice.call(document.querySelectorAll(".el-form-item"));
    for (var i = 0; i < items.length; i++) {
      var lb = items[i].querySelector(".el-form-item__label");
      if (!lb) continue;
      var t = (lb.textContent || "").replace(/\s+/g, "");
      if (!/验证码|图形码|校验码|附加码/.test(t)) continue;
      var img = items[i].querySelector("img, canvas");
      if (img && img.offsetParent !== null) return img;
    }
    // 2) 通用 label
    var labels = Array.prototype.slice.call(document.querySelectorAll("label, .form-label, td"));
    for (var j = 0; j < labels.length; j++) {
      var t2 = (labels[j].textContent || "").replace(/\s+/g, "");
      if (!/验证码|图形码|校验码|附加码/.test(t2)) continue;
      var scope = labels[j].closest(".el-form-item, tr, .form-group") || labels[j].parentElement;
      if (!scope) continue;
      var img2 = scope.querySelector("img, canvas");
      if (img2 && img2.offsetParent !== null) return img2;
      var sib = scope.parentElement;
      if (sib) {
        var img3 = sib.querySelector("img, canvas");
        if (img3 && img3.offsetParent !== null) return img3;
      }
    }
    // 3) 兜底选择器
    var sels = [
      "img[alt*='验证码']", "img[alt*='校验码']", "img[alt*='附加码']",
      "img[id*='captcha']", "img[id*='verifyCode']", "img[class*='captcha']",
      "canvas[id*='captcha']", "canvas[class*='captcha']",
      ".verify-code-container img", ".verify-code-container canvas",
      "img[src*='verifyCode']", "img[src*='captcha']", "img[src*='ValidateCode']"
    ];
    for (var k = 0; k < sels.length; k++) {
      var el = document.querySelector(sels[k]);
      if (el && el.offsetParent !== null) return el;
    }
    return document.querySelector("script[data-sx-captcha-base64],script[data-captcha-base64]");
  }

  function findCaptchaInput() {
    var inputs = Array.prototype.slice.call(document.querySelectorAll("input"));
    for (var i = 0; i < inputs.length; i++) {
      var el = inputs[i];
      if (el.type === "hidden" || el.disabled || el.offsetParent === null) continue;
      var nm = String(el.name || "").toLowerCase();
      var ph = String(el.getAttribute("placeholder") || "").toLowerCase();
      var id = String(el.id || "").toLowerCase();
      var label = (el.closest(".el-form-item, .form-group, tr") || {}).textContent || "";
      var own = nm + "|" + ph + "|" + id;
      if (/sms|message|短信|动态|手机验证码/i.test(own)) continue;
      if (!/图形|图片|图像|captcha|imagecode/i.test(own) && /短信|手机验证码/.test(label)) continue;
      if (/captcha|verifycode|vcode|验证码|附加码|校验码|图形码/.test(nm + "|" + ph + "|" + id)) return el;
    }
    var labels = document.querySelectorAll('.el-form-item__label,label,.form-label');
    for (var j = 0; j < labels.length; j++) {
      var lb = labels[j], text = lb.textContent || '';
      if (!/图形|图片|验证码|校验码|附加码/.test(text) || /短信|手机验证码/.test(text)) continue;
      var scope = lb.closest('.el-form-item,.form-group,tr') || lb.parentElement;
      var target = lb.querySelector('input') || (lb.htmlFor && document.getElementById(lb.htmlFor));
      if (!target && lb.nextElementSibling && lb.nextElementSibling.tagName === 'INPUT') target = lb.nextElementSibling;
      if (!target && scope && scope.querySelectorAll('input').length === 1) target = scope.querySelector('input');
      if (target && !target.disabled && target.type !== 'hidden' && target.offsetParent !== null) return target;
    }
    return null;
  }

  function getCurrentCaptchaSignature(img) {
    try {
      if (!img) return "";
      if (img.tagName === "SCRIPT") return img.dataset ? (img.dataset.sxCaptchaBase64 || img.dataset.captchaBase64 || "") : "";
      if (img.tagName === "CANVAS") {
        try { return img.toDataURL("image/png"); } catch (e) {}
        return img.className || "";
      }
      return img.getAttribute("src") || (img.dataset && img.dataset.src) || img.currentSrc || "";
    } catch (e) { return ""; }
  }

  function observeCaptchaChanges() {
    if (captchaObserver) return;
    var body = document.body;
    if (!body) return;
    var isCaptchaNode = function (n) {
      if (!n || n.nodeType !== 1 || typeof n.matches !== "function") return false;
      if (n.matches("img,canvas,script[data-sx-captcha-base64],script[data-captcha-base64]")) return true;
      return false;
    };
    captchaObserver = new MutationObserver(function (mutations) {
      try {
        var hit = mutations.some(function (m) {
          if (m.type === "attributes") {
            var n = m.target;
            if (!n || typeof n.matches !== "function") return false;
            if (n.matches("img,canvas,script[data-sx-captcha-base64],script[data-captcha-base64]")) return true;
            var attr = m.attributeName || "";
            return attr === "src" || attr === "data-src" || attr === "data-sx-captcha-base64" || attr === "data-captcha-base64";
          }
          if (m.type === "childList") {
            var added = Array.prototype.slice.call(m.addedNodes || []).some(isCaptchaNode);
            var removed = Array.prototype.slice.call(m.removedNodes || []).some(isCaptchaNode);
            return added || removed;
          }
          return false;
        });
        if (hit) handleCaptchaChange();
      } catch (e) {}
    });
    captchaObserver.observe(body, {
      childList: true, subtree: true, attributes: true,
      attributeFilter: ["src", "data-src", "data-sx-captcha-base64", "data-captcha-base64", "style", "class"]
    });
  }

  function handleCaptchaChange(reason) {
    var sig = getCurrentCaptchaSignature(findCaptchaImage());
    if (!sig) return;
    if (!captchaObserverPrimed) { captchaObserverPrimed = true; lastCaptchaSignature = sig; return; }
    if (sig === lastCaptchaSignature) return;
    lastCaptchaSignature = sig;
    getOptions().then(function (cfg) { if (cfg.autoOcr) runOcr(); });
  }

  /* ============ 图片 → base64 ============ */
  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () {
        var d = fr.result;
        if (typeof d === "string") resolve(d); else reject(new Error("读取失败"));
      };
      fr.onerror = function () { reject(fr.error || new Error("读取失败")); };
      fr.readAsDataURL(blob);
    });
  }
  async function getImageBase64(img) {
    try {
      if (!img) return "";
      if (img.tagName === "CANVAS" && typeof img.toDataURL === "function") return img.toDataURL("image/png");
      if (img.tagName === "SCRIPT") return String(img.dataset.sxCaptchaBase64 || img.dataset.captchaBase64 || "").replace(/^data:image\/[^;]+;base64,/, "");
      var src = img.getAttribute("src") || (img.dataset && img.dataset.src) || img.currentSrc || "";
      if (/^data:image/i.test(src)) return src.split(",")[1] || "";
      // canvas 兜底（跨域图片在部分银行页不能直接 fetch）
      try {
        if (img.complete !== false) {
          var cv = document.createElement("canvas");
          cv.width = img.naturalWidth || img.width || 120;
          cv.height = img.naturalHeight || img.height || 40;
          var ctx = cv.getContext("2d");
          if (ctx) { ctx.drawImage(img, 0, 0); return cv.toDataURL("image/png"); }
        }
      } catch (e) {}
      if (!src) return "";
      var res = await fetch(src, { mode: "cors", credentials: "include", cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      var blob = await res.blob();
      return await blobToBase64(blob);
    } catch (e) { warn("获取验证码图片失败: " + e.message); return ""; }
  }

  /* ============ OCR：App 原生链路 ============ */
  window.addEventListener("message", function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (!d || d.type !== "SX_OCR_RESULT") return;
    var w = _ocrWaiters[d.id];
    if (!w) return;
    delete _ocrWaiters[d.id];
    if (d.error) w.reject(new Error(d.error));
    else w.resolve(d.text || "");
  });

  function appOcr(b64) {
    return new Promise(function (resolve, reject) {
      var id = "sx_ocr_" + Date.now() + "_" + (++_ocrSeq);
      var cfgEl = document.createElement("script");
      cfgEl.type = "application/json";
      cfgEl.id = "sx_ocr_config_" + id;
      cfgEl.textContent = JSON.stringify({
        messageId: id,
        imageDataUrl: /^data:image/i.test(b64) ? b64 : "data:image/png;base64," + b64,
        pngFix: false,
        colorFilterColors: (window.shuixian && window.shuixian.detect() || {}).id === "PSBC" ? ["red"] : null
      });
      (document.head || document.documentElement || document.body).appendChild(cfgEl);
      _ocrWaiters[id] = { resolve: resolve, reject: reject };
      try {
        if (typeof window.__SX_OCR_RUN__ === "function") window.__SX_OCR_RUN__();
        else { throw new Error("App OCR 桥未就绪"); }
      } catch (e) {
        if (_ocrWaiters[id]) { delete _ocrWaiters[id]; reject(e); }
      }
      setTimeout(function () {
        if (_ocrWaiters[id]) {
          delete _ocrWaiters[id];
          reject(new Error("OCR 超时"));
        }
      }, 40000);
    });
  }

  var activeOcr = null;
  function runOcr() {
    if (activeOcr) return activeOcr;
    activeOcr = performOcr().then(function (r) { activeOcr = null; return r; }, function (e) { activeOcr = null; throw e; });
    return activeOcr;
  }
  async function performOcr() {
    try {
      var img = findCaptchaImage();
      if (!img) return { ok: false, msg: "未找到验证码图片，请手动输入" };
      var signature = getCurrentCaptchaSignature(img);
      var b64 = await getImageBase64(img);
      if (!b64) return { ok: false, msg: "验证码图片读取失败，请手动输入" };
      var text = await appOcr(b64);
      text = String(text || "").replace(/\s+/g, "").trim();
      if (!text) return { ok: false, msg: "识别结果为空，请手动输入" };
      if (findCaptchaImage() !== img || getCurrentCaptchaSignature(img) !== signature)
        return { ok: false, msg: "验证码已刷新，请重新识别" };
      var input = findCaptchaInput();
      if (input) {
        if (C.fillValue) C.fillValue(input, text);
        else {
          input.value = text;
          input.dispatchEvent(new Event("input", { bubbles: true }));
          input.dispatchEvent(new Event("change", { bubbles: true }));
        }
        return { ok: true, msg: "验证码已自动填入：" + text };
      }
      return { ok: false, msg: "识别成功：" + text + "（未找到输入框，请手动填入）" };
    } catch (e) {
      warn("OCR 识别失败: " + (e && e.message));
      return { ok: false, msg: "识别失败：" + ((e && e.message) || e) };
    }
  }

  /* ============ 一键全自动填表 ============ */
  var fillRunning = false;
  async function fillFormWithPerson(person) {
    if (fillRunning) { toast("正在填写，请稍候", "warning"); return; }
    fillRunning = true;
    try {
      var allowed = await new Promise(function (resolve) {
        var timer = setTimeout(function () { resolve(false); }, 35000);
        if (typeof window.__SX_GATE_ENSURE__ !== "function") { clearTimeout(timer); resolve(false); return; }
        window.__SX_GATE_ENSURE__(function (ok) { clearTimeout(timer); resolve(ok === true); });
      });
      if (!allowed) { toast("授权校验未通过，请打开设置检查激活状态", "warning"); return; }
      var bank = detectAdapter();
      if (!bank) { toast("当前页面不是支持的银行预约页", "warning"); return; }
      var p = toAdapterPerson(person);
      var idNo = String(p.id_card || "").trim();
      if (idNo) {
        if (typeof window.__SX_CHECK_PERSON__ !== "function") { toast("人员校验未就绪，请刷新后重试", "warning"); return; }
        var checked = await new Promise(function (resolve) {
          var timer = setTimeout(function () { resolve(null); }, 35000);
          window.__SX_CHECK_PERSON__(idNo, function (r) { clearTimeout(timer); resolve(r); });
        });
        if (!checked || checked.code !== 0 || !checked.blocked || typeof checked.blocked !== "object" || Array.isArray(checked.blocked)) {
          toast("人员校验失败，请检查网络后重试", "warning"); return;
        }
        var normalizedId = idNo.toUpperCase();
        if (Object.keys(checked.blocked).some(function (key) { return String(key).trim().toUpperCase() === normalizedId; })) {
          toast("该人员暂不可使用，请联系管理员", "warning"); return;
        }
      }
      if (bank.waitForOpen) await bank.waitForOpen();
      if (bank.fillForm) await bank.fillForm(p); else defaultFillForm(bank, p);
      if (C.autoCheckAgreementCheckboxes) C.autoCheckAgreementCheckboxes();
      var cfg = await getOptions();
      var ocrR = cfg.autoOcr ? await runOcr() : {ok:false,msg:"自动识别已关闭"};
      if (!ocrR.ok) toast(ocrR.msg, "warning");
      cfg = await getOptions();
      if (!cfg.autoSubmit) { toast("信息已填写，请手动提交", "info"); return; }
      var captcha = findCaptchaInput();
      if (captcha && !String(captcha.value || "").trim()) { toast("请先填写图形验证码，再手动提交", "warning"); return; }
      if (typeof bank.submit !== "function") { toast("已填写完成，请手动提交", "warning"); return; }
      var preflight=C.validateBeforeSubmit();
      if(!preflight.ok){toast(preflight.message,"warning");return;}
      await delay(600);
      var recheck=C.validateBeforeSubmit();
      if(!recheck.ok){toast(recheck.message,"warning");return;}
      var submitted = await bank.submit();
      if (submitted === false) { toast("未找到可用提交按钮，请手动提交", "warning"); return; }
      var ok = typeof bank.verifyResult === "function" ? await bank.verifyResult() : false;
      toast(ok ? "预约成功！" : "已尝试提交，请确认页面结果", ok ? "success" : "warning");
    } catch (e) { toast("填写失败：" + (e.message || e), "warning"); }
    finally { fillRunning = false; }
  }

  // 适配器无 fillForm 时的默认填写（用 getSelectorMap）
  function defaultFillForm(bank, p) {
    try {
      if (!bank || typeof bank.getSelectorMap !== "function") return;
      var sel = bank.getSelectorMap();
      var set = function (s, v) {
        if (!s || v == null || v === "") return;
        var el = document.querySelector(s);
        if (el) {
          el.value = v;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
        }
      };
      set(sel.fullName, p.name);
      set(sel.idNumber, p.id_card);
      set(sel.mobile, p.phone);
      if (sel.idType) {
        var it = document.querySelector(sel.idType);
        if (it) {
          var opts = it.querySelectorAll("option");
          for (var i = 0; i < opts.length; i++) {
            if (opts[i].text.indexOf("身份证") >= 0 || opts[i].value === "01") {
              it.value = opts[i].value;
              it.dispatchEvent(new Event("change", { bubbles: true }));
              break;
            }
          }
        }
      }
      if (sel.regionSelects) {
        var parts = [p.province, p.city, p.district];
        for (var j = 0; j < sel.regionSelects.length && j < parts.length; j++) {
          var rs = document.querySelector(sel.regionSelects[j]);
          if (rs && parts[j]) {
            var opts2 = rs.querySelectorAll("option");
            for (var k = 0; k < opts2.length; k++) {
              if (opts2[k].text.indexOf(parts[j]) >= 0) {
                rs.value = opts2[k].value;
                rs.dispatchEvent(new Event("change", { bubbles: true }));
                break;
              }
            }
          }
        }
      }
      if (sel.branch && p.branch) set(sel.branch, p.branch);
    } catch (e) { warn("默认填写异常: " + e.message); }
  }

  /* ============ 浮窗 ============ */
  function openSettings() {
    try {
      if (window.chrome && window.chrome.runtime && typeof window.chrome.runtime.sendMessage === "function") {
        chrome.runtime.sendMessage({ type: "OPEN_LICENSE_POPUP" }, function () {});
      }
    } catch (e) {}
  }

  function copyWechat() {
    try {
      var ta = document.createElement("textarea");
      ta.value = "lumiannb666";
      ta.style.cssText = "position:fixed;opacity:0;";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      toast("微信号已复制：lumiannb666", "success");
    } catch (e) {
      toast("微信号：lumiannb666", "info");
    }
  }

  function showRestoreButton() {
    if (document.getElementById('sx-app-restore')) return;
    var button = document.createElement('button'); button.id = 'sx-app-restore'; button.textContent = '预约';
    button.style.cssText = 'position:fixed;right:12px;top:40%;z-index:9999999;border:0;border-radius:24px;padding:12px;background:#2563eb;color:white;';
    button.onclick = function () { button.remove(); floatMinimized = false; if (!floatingWindow) buildFloat(); else floatingWindow.style.display = ''; };
    (document.body || document.documentElement).appendChild(button);
  }
  function buildFloat() {
    if (floatingWindow) { try { floatingWindow.remove(); } catch (e) {} }
    floatingWindow = document.createElement("div");
    floatingWindow.id = "sx-app-float";
    floatingWindow.style.cssText =
      "position:fixed;top:120px;right:16px;width:236px;z-index:9999998;" +
      "background:linear-gradient(165deg,#3b82f6 0%,#2563eb 50%,#1e3a8a 100%);border-radius:14px;box-shadow:0 8px 32px rgba(15,40,120,.35);" +
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;" +
      "user-select:none;overflow:hidden;";

    var style = document.createElement("style");
    style.textContent =
      ".sx-app-float-head{background:transparent;color:#fff;padding:10px 12px;" +
      "display:flex;justify-content:space-between;align-items:center;cursor:move;}" +
      ".sx-app-avatar{width:28px;height:28px;border-radius:50%;border:2px solid rgba(255,255,255,.75);" +
      "object-fit:cover;margin-right:7px;display:block;flex:none;}" +
      ".sx-app-float-title{font-size:13px;font-weight:600;text-shadow:0 1px 2px rgba(0,0,0,.2);}" +
      ".sx-app-float-actions{display:flex;align-items:center;gap:4px;}" +
      ".sx-app-float-btn{background:rgba(255,255,255,.2);border:none;color:#fff;font-size:14px;width:26px;height:26px;" +
      "border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;}" +
      ".sx-app-announce{background:rgba(255,255,255,.96);border:1px solid rgba(255,255,255,.6);border-radius:10px;padding:8px 10px;margin:8px;" +
      "font-size:11px;color:#333;line-height:1.5;cursor:pointer;}" +
      ".sx-app-body{padding:4px 8px 10px;max-height:320px;overflow-y:auto;}" +
      ".sx-app-person{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:9px 10px;margin-bottom:7px;" +
      "cursor:pointer;transition:all .15s;}" +
      ".sx-app-person:active{background:#eef2ff;border-color:#2563eb;}" +
      ".sx-app-person-name{font-size:13px;font-weight:600;color:#111827;display:flex;align-items:baseline;gap:6px;}" +
      ".sx-app-person-remark{font-size:11px;color:#9ca3af;font-weight:400;}" +
      ".sx-app-person-info{font-size:11px;color:#6b7280;margin-top:3px;line-height:1.4;word-break:break-all;}" +
      ".sx-app-empty{text-align:center;padding:18px 8px;color:#cfe0ff;font-size:12px;}" +
      ".sx-app-foot{display:flex;gap:8px;padding:8px;}" +
      ".sx-app-go{flex:1;padding:9px 0;background:#fff;color:#1d4ed8;font-weight:600;border:none;" +
      "border-radius:8px;font-size:13px;cursor:pointer;}" +
      ".sx-app-go:active{background:#e5edff;}";
    (document.head || document.documentElement).appendChild(style);

    floatingWindow.innerHTML =
      '<div class="sx-app-float-head"><span style="display:flex;align-items:center;">' +
      '<img class="sx-app-avatar" src="data:image/webp;base64,UklGRkwLAABXRUJQVlA4IEALAACQKwCdASpgAGAAPmEokUYkIiGhK5TqyIAMCWQAnTmN0/45ft/6b6JVl7KDSfnFOY+qbzAOdv5jPOK9K39x317eYv8Ran/E/9H4Y+Xz3pLhb5dSn5b91P2/DfwCPYf+Z3yEAX59/a+/x1RMgD9XONBoAfzr+2/+P1Xf+rzE/Tf/q9wr+c/2P/rdk/9pPZLYEiUc6jYlWbXmWIt8vNXF5VO1l34JRaeg50Yz6/0+YsGYykvLiYw0oRNH9BUnotcnhxfFKFGGvnLlwRkQqzYxPS3LpTeJ4wrWg+76zoEYI/eHwW+XQmURXS6Se+hyu1hUNJu7TY8+K/XvnHlbhwdWwVjw3rzVjbG/2XtQgvCV/k1bKjdycSpd6G7B6hBN5P5OIDnyLb25TnngSf2yq6bvcoO5zx98eaas16Al0vUhkFciwBnt5j4ydgcC38ksXTK6985sVneqZM3VEwttWOL30hayHXHvNwAA/u32Fd+2xeIBIrPu/kMjcqYC/SrwWgme4pzT76rGNIq3GrHnKV9er0HAYio16O5/tOfqO9lr4w//cK8E/vdkevvv22YxSnxJUOEf+ZdH5WkQ78YGeZGM1/2SfGeax9nBADIMIOnV3+slid4tGRfWJFJcHx+F4v/1v5Ga7MPz/8DGJHb/uwGUXH1+idlUW6z59KtloiZqfSOgYnSSdmzi7+BJIJoAqXRVfuf2juxqlTMRBkQASXsycwqbTgXxm/SwzmL2q7UOLR26+SqqqPdQTiTfeeOQQtmGL20CVijmzI9aA9tdj4hXxg/ekgRWRoRmmCPbY/7eeXXJefcwaOD+QTxo3LT0cDs5S5N068OYtGLJzoIzIlMgS5iUj8/lRbo7nJyzIBJi/8/5aNVzCz8oeQSFXfVSuYrx8X8GVuD+FwP9RJHLeSalqjHlEhbo9PjcdV953hfCfShNDfNlWZi/jx/YI8rCRpNUENXO5G0gNyNiHY+LppsLvKmgY3wW+tqdBfM4+nRV59rOUTBY9YFVWtmHD5eZo3Q5yGnXRB1UDqldT+ksgXq5bn5uK5OP6taOcmH7L/jRpGD2mbfI9vH8R08e9YIXUX2KL6MmqTvS6qIi8uypgb6Evf0XJV+5M/ckXgiY/9+Rr2HmHKODFJo7+zpxcv8ktBEhfbGZNqcoouKPtKJ6P94NA0aBjDSPPhUYGgzEevtUry9vZN155cJ90bjU7GONHP4NeQumLAbAv6ptbltOqkl+PhkEkYvoWJ3eAv/MeX7bY9aPF0rrTP88gkH4GoY0xSogQFNF2cUd5xT+lIOPO/ndd9A7bgeeNijjy+TSOLnnI0Mghr1U2em2oGpQs9oNADb58vU8ZcA+XbRJIBSJXsEsRRaVhTCKtZcPgFX2TxGAVf1n0g28AHxcCzLt1NQ3ejJ9tynPDbs//p3PPgWPgwiNkH7XBxgMgk3VfMt7oxZFqp+C2ts45XRDUUIe3MNYRe3H7XhFdIzw/nj9gyyWe8luy8CqPjU75QkJxXBzwrVXMDkxzZM3aRT7PBsWa+emyuXV/Qo1IsuC3DQpcN/N6Z7r3z3IC2wR9MeqQE6CKtzIMQSKm1V6QjqXKFtv/16VmRYg7WipOfS0PHBdmpLOVlVy3QlWhkflsrvoNVJaR20ZCGVIwHDkltefJ4EOjr83uf0w3AXYzWCefuMU44ocH6ip2J5bNw2vEWyYkmHvCM3mbzSqSRSXvpxwp0ZuoZLYj9X8H2c0osUix/hrvzvhOrI5YhPdtuwnHYqxv6o9ycM5u1aAVhFCLXG0mT5QSVqYTcxxc+Z1pV4di25bnoMIaiLwzPhQZ/1fwzdSTwpaLlXRzBJJu6uIeb/6e2J+LS3XPqN3YNCOJiKwzbHjefoON0rbzioH8QScVRfL9R1UhQxVKRBn5f5xxjrddDNA5SghRW9goymRjBQAIgd1lrcU/Ze+DdwSBHPnH+5eJ/K0Z2E0SLcihnHljx2heXBjQTbzOL3//PeykmnoX6NVVRduHsUxe50Pb0WPjkro0CoTxAz+6U7JmXAEnsZr1S5WqcYQxaff5e8msA8nNLhMZEfDbfdTQ5YACXohXZxJbya4u8zILwRRHWyko1nEFkplfFoJ90z0gYlqhFZZ6rdKG7mK2NVGzWDoVCJbPsX7zBKCdAqIR95KN1duINIrbKZIaBMYwsH0tmIt0EJzhSGWInaBAtjKYntwGDYnmrtJ211Dd/kDytIPyNyN0ZbSOzqH+9zXt4sMNZqTZLic7Ka8K0slDC8xKMyWrzneGHqZzdN9e6yKnsuPnENBfq/InHuSOWzW1askqg3l50W1TV2+AquhPf12mmAqUI/sCPpsDfinvlqfYJC+hXa082ygGPYNsfDzkAHFd3NrBwy8R4FKrsf3r6P2eCFMzcG1r+fLzJuVOozAfG7B9ZmQrbx1PDXSynnHa1eNMsjQej02wW9gN8SmMqofYzb9C4iyFWkozBrlLMi+W0qlc8KkM+sG3AoDmq0fCjNnBig9AiSW9zG4DFNj/bM3Y+Hbp97NHip6YFdl8gJOIX0c19wMiLt+tWC27zRBndruo74xha5eFmXeCyXAfd4QoqIsTeXJUy/YbjSjKOsJdrf0AfzWgUdquwgM1Uwgb8qVswI/gb/G1l7eL4d5jw7EeU0tGrIMEhFp9uChbzwcbjxjD9EMtkAcdVt/Ww/u43T5jreVpAqzgreFg8BPXf3h4nI+pehka9T5ZD1Zb+XxOVssD8UxfW8XAC1kAnhphx5qfsuzGkieuVjZyoaUEuzKCKm66pPfHfV5LuF5IThPYETWRdFicfYttNIvf4RiCounQwl3+hCwjKAfSZrv87/gnVTUP1tYzQ62GyTj+3bMzG9vCKSRrggvAe18ps8UlXgCHMKSSmc70H1+r7hUVVeIw02QgStgYoMN2/vW+GjVsmHXuP3gEC08qCPAoY8pOWcwV0Kqy1sp8BhZh4JnMoBrQ6q/4ul48RQoL+DQLs52fYU4LuuKhMb2pXiBjaljsb6TMEHnGfg0EVJawbfUIOlS7xj3y7rsYJjzUdiFNDpOVVxOquWhpMKf0p4D863mFrGmNpIk+ioQ6bQtpkTm3+NHmStu1IgzkO/ZMgFmBAEffyipDwzYV6iPjX9qKAvFdj2YN5dvGvHO++qLznIbeUoGo/omzoqGcKs8PJ27P/d9/HWbWzjTmgvQvKrG1PhRZ9zc3uAhlym2r6v7RD4KZaxWsGifM4JLusGa4O5htkipdzrIEm8DFu7OVHfLKJWuLYFkwd2XUyk8Z5SCNFewplvk/lOfnmgbKOBKPSdHCXpxBaSzrtImfQMvJJcFMQFQe+ONvoJSS+Bzy9ecFsyKGT3y/wqMw0ETQ9qRioEum5mPdNR8QHhOp2uvfZGSetNBAyv/9mypbpUKKXo8dCfOXrqq8Jph1tP5lNWaiX4PT48EcHBbcSzqsjPUo0Hjy2UlwskjyY0n/p6pIk2xUnANz+AN/WDbjJQUoSyhz9U1zzdsnoIsHJmDkff+y435xwoHMMLlAtOLruGRgTWwXLt/ghZ2/VHWqG27jnMjDSbayGlYugy3/DG9fd6bjYq0JfJZ9ZV2cefP2IBpRhVgSFET7eg4XgM3tebb4jeyKGy/z4xSWE3nZe5o2tbAScLTnanivshqAy/UBxkOhLJqubiS/ichb9B8B70AW9PvKOM83fTCjvy2xr8zuNyrsmHx5EbRAbQMLOdHYKCM15JNurwtge72ZUq8t1zQjaQZxNdhmFxIAXat/6kVQ4uDvkK3IufbKIrtqrMRBPHcN/HIj906BQg9hywYvHexieKX0PbrjxE1mxbDrFT79ASAJhDtjGX8RYloAAA=" alt="">' +
      '<span class="sx-app-float-title">路面纪念钞币科技</span></span>' +
      '<div class="sx-app-float-actions">' +
      '<button class="sx-app-float-btn" id="sx-app-set" title="添加/管理人员">⚙</button>' +
      '<button class="sx-app-float-btn" id="sx-app-close" title="最小化">—</button>' +
      '</div></div>' +
      '<div class="sx-app-announce" id="sx-app-wx">' +
      '需要出纪念物品的可以➕微信 <b style="color:#d97706;">lumiannb666</b><br/>（点击复制）</div>' +
      '<div class="sx-app-body" id="sx-app-list"><div class="sx-app-empty">加载中...</div></div>' +
      '<div class="sx-app-foot">' +
      '<button class="sx-app-go" id="sx-app-all">一键填写（首位）</button><button class="sx-app-go" id="sx-app-ocr">识别验证码</button></div>';
    (document.body || document.documentElement).appendChild(floatingWindow);

    // 公告 → 复制微信
    var wxEl = floatingWindow.querySelector("#sx-app-wx");
    if (wxEl) wxEl.addEventListener("click", copyWechat);

    // 设置 / 关闭
    var setBtn = floatingWindow.querySelector("#sx-app-set");
    if (setBtn) setBtn.addEventListener("click", function (e) { e.stopPropagation(); openSettings(); });
    var closeBtn = floatingWindow.querySelector("#sx-app-close");
    if (closeBtn) closeBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      floatMinimized = true;
      floatingWindow.style.display = "none";
      showRestoreButton();
    });

    var ocrBtn = floatingWindow.querySelector("#sx-app-ocr");
    if (ocrBtn) ocrBtn.addEventListener('click', async function () { var result = await runOcr(); toast(result.msg, result.ok ? 'success' : 'warning'); });
    // 一键全自动：第一个人
    var goBtn = floatingWindow.querySelector("#sx-app-all");
    if (goBtn) goBtn.addEventListener("click", function () {
      if (personsData.length === 0) { toast("还没有人员，先点 ⚙ 添加", "warning"); return; }
      fillFormWithPerson(personsData[0]);
    });

    // 拖动（touch + mouse）
    var head = floatingWindow.querySelector(".sx-app-float-head");
    function onDown(x, y) {
      if (floatingWindow) {
        isDragging = true;
        var r = floatingWindow.getBoundingClientRect();
        dragOffset.x = x - r.left;
        dragOffset.y = y - r.top;
      }
    }
    function onMove(x, y) {
      if (!isDragging || !floatingWindow) return;
      var maxX = window.innerWidth - floatingWindow.offsetWidth;
      var maxY = window.innerHeight - floatingWindow.offsetHeight;
      var nx = Math.max(0, Math.min(x - dragOffset.x, maxX));
      var ny = Math.max(0, Math.min(y - dragOffset.y, maxY));
      floatingWindow.style.left = nx + "px";
      floatingWindow.style.top = ny + "px";
      floatingWindow.style.right = "auto";
    }
    function onUp() { isDragging = false; }
    if (head) {
      head.addEventListener("touchstart", function (e) {
        if (e.target.closest("button")) return;
        var t = e.touches[0]; onDown(t.clientX, t.clientY);
      }, { passive: true });
      head.addEventListener("touchmove", function (e) {
        if (!isDragging) return;
        var t = e.touches[0]; onMove(t.clientX, t.clientY);
        try { e.preventDefault(); } catch (err) {}
      }, { passive: false });
      head.addEventListener("touchend", onUp);
      head.addEventListener("mousedown", function (e) { if (!e.target.closest("button")) onDown(e.clientX, e.clientY); });
      document.addEventListener("mousemove", function (e) { onMove(e.clientX, e.clientY); });
      document.addEventListener("mouseup", onUp);
    }

    // 渲染人员列表
    loadPersons().then(function (list) {
      personsData = list;
      renderPersonList();
    });
  }

  function renderPersonList() {
    var listEl = floatingWindow && floatingWindow.querySelector("#sx-app-list");
    if (!listEl) return;
    if (personsData.length === 0) {
      listEl.innerHTML = '<div class="sx-app-empty">暂无人员信息<br/>点右上角 ⚙ 添加</div>';
      return;
    }
    var html = "";
    for (var i = 0; i < personsData.length; i++) {
      var p = personsData[i];
      var name = esc(p.name || "未命名");
      var remark = p.remark ? esc(p.remark) : "";
      var info = [p.idcard || p.id_card || "", p.phone || p.mobile || ""]
        .filter(function (s) { return s; }).join(" · ");
      html += '<div class="sx-app-person" data-idx="' + i + '">' +
        '<div class="sx-app-person-name">' + name +
        (remark ? '<span class="sx-app-person-remark">-' + remark + '</span>' : '') +
        '</div>' +
        (info ? '<div class="sx-app-person-info">' + esc(info) + '</div>' : '') +
        '</div>';
    }
    listEl.innerHTML = html;
    var cards = listEl.querySelectorAll(".sx-app-person");
    for (var j = 0; j < cards.length; j++) {
      cards[j].addEventListener("click", function () {
        var idx = parseInt(this.getAttribute("data-idx"), 10);
        var p = personsData[idx];
        if (p) fillFormWithPerson(p);
      });
    }
  }

  /* ============ 初始化 ============ */
  function tryInit() {
    if (floatingWindow) return;
    if (!isSupportedBankPage()) return;
    buildFloat();
  }

  function boot() {
    // 暴露主填表入口（date_fill.js 的兜底 hook 目标，也便于外部调用/测试）
    window.__SX_FILL_FORM__ = fillFormWithPerson;
    tryInit();
    // 监听 App 侧人员变化 → 刷新列表
    try {
      if (window.chrome && window.chrome.storage && window.chrome.storage.local &&
          window.chrome.storage.local.onChanged) {
        chrome.storage.local.onChanged.addListener(function (changes, area) {
          if (!changes || area !== "local") return;
          if (changes.userSettings && floatingWindow) {
            loadPersons().then(function (list) {
              personsData = list;
              renderPersonList();
            });
          }
        });
      }
      if (window.__sxFirePersonsChanged) { /* bridge 已触发 onChanged */ }
    } catch (e) {}

    // 监听验证码变化（银行页）
    observeCaptchaChanges();

    // SPA 路由/延迟加载 → 周期性重挂载浮窗
    setInterval(function () {
      try {
        if (floatingWindow && floatingWindow.isConnected === false) floatingWindow = null;
        if (!floatingWindow && isSupportedBankPage()) { if (floatMinimized) showRestoreButton(); else buildFloat(); }
      } catch (e) {}
    }, 2000);
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    setTimeout(boot, 600);
  } else {
    window.addEventListener("DOMContentLoaded", function () { setTimeout(boot, 600); });
  }
})();

/* Reservation result observer: local identity matching, no bank requests or submissions. */
(function(){
'use strict';
if(window.__SX_RESULT_TRACKER__)return;
var api=window.__SX_RESULT_TRACKER__={};
var aliases={status:['预约状态','申请状态'],product:['预约币种','预约品种','预约产品','产品名称','纪念币名称'],branch:['兑换网点','预约网点','领取网点'],address:['网点地址','兑换地址','领取地址'],date:['兑换时间','兑换日期','领取日期'],quantity:['预约数量','兑换数量'],name:['客户姓名','预约人姓名','姓名'],id:['证件号码','证件号','身份证号码','身份证号'],phone:['手机号码','手机号','联系电话']};
var all=Object.keys(aliases).reduce(function(a,k){return a.concat(aliases[k]);},[]).sort(function(a,b){return b.length-a.length;});
function clean(s){return String(s||'').replace(/\u00a0/g,' ').trim();}
function parse(text){
 text=clean(text);var out={};
 Object.keys(aliases).forEach(function(key){
  var rx=new RegExp('(?:^|\\n)\\s*(?:'+aliases[key].join('|')+')\\s*[:：]\\s*([\\s\\S]*?)(?=\\n\\s*(?:'+all.join('|')+')\\s*[:：]|$)');
  var hit=text.match(rx);if(hit)out[key]=clean(hit[1]).split('\n')[0].trim();
 });
 if(!out.branch || !out.product)return null;
 var accepted=/^(?:预约已受理|预约申请已受理|预约成功|预约申请成功|申请成功|预约提交成功)$/.test(clean(out.heading));
 // Headings are checked independently in the DOM; text-only parser requires a standalone marker.
 accepted=accepted||/(?:^|\n)\s*(?:预约已受理|预约申请已受理|预约成功|预约申请成功|预约提交成功)\s*(?:\n|$)/.test(text);
 if(!accepted || /失败|未成功|取消|已撤销|未受理|无效/.test(out.status||''))return null;
 out.bank_status=out.status||'';
 out.status=/(?:^|\n)\s*预约(?:申请)?已受理\s*(?:\n|$)/.test(text)||/待核查|待审核|受理|待确认/.test((out.status||'')+text.split('\n').slice(0,8).join(''))?'accepted':'confirmed';
 return out;
}
function matches(actual,shown){
 actual=clean(actual).replace(/\s/g,'').toUpperCase();shown=clean(shown).replace(/\s/g,'').toUpperCase();
 if(!actual||!shown)return false;
 var escaped=shown.replace(/[.+?^${}()|[\]\\]/g,'\\$&').replace(/[*＊•●×]+/g,'.+');
 try{return new RegExp('^'+escaped+'$').test(actual);}catch(e){return false;}
}
function identify(result,people){
 var unique={};(people||[]).forEach(function(p){var id=clean(p.id_card||p.idcard||p.idNumber).toUpperCase(),name=clean(p.name||p.fullName),phone=clean(p.phone||p.mobile);
  var idHit=matches(id,result.id),phoneHit=matches(phone,result.phone),nameHit=matches(name,result.name);
  // Masked pages must agree on at least two independent fields; a full ID suffices.
  if(result.phone && !phoneHit)return; if(result.name && !nameHit)return;
  if(id && ((idHit && (phoneHit||nameHit)) || (idHit && clean(result.id).toUpperCase()===id)))unique[id]={id_card:id,name:name,phone:phone};
 });var ids=Object.keys(unique);return ids.length===1?unique[ids[0]]:null;
}
api.parse=parse;api.matches=matches;api.identify=identify;
function people(){return new Promise(function(resolve){try{chrome.storage.local.get(['persons','userSettings'],function(v){var x=v.persons||v.userSettings||[];try{if(typeof x==='string')x=JSON.parse(x);}catch(e){x=[];}resolve(Array.isArray(x)?x:(x&&x.name?[x]:[]));});}catch(e){resolve([]);}});}
function notify(message) { /* Background-only reporting; keep the bank result page unchanged. */ }
var inFlight=false,done={},tries={},nextAttempt={},timer=null;
function schedule(){clearTimeout(timer);timer=setTimeout(scan,900);}
api.readResult=function(){ var text=(document.body&&document.body.innerText)||'',result=parse(text);if(!result)return null;
 // A live editable reservation form or stale toast is not a result page.
 var liveFields=Array.prototype.filter.call(document.querySelectorAll('input'),function(el){return !el.disabled&&!el.readOnly&&!/^(hidden|button|submit|checkbox|radio)$/.test(el.type)&&el.getClientRects().length>0&&/idcard|idnumber|certno|mobile|phone|fullname|username|客户姓名|身份证号|手机号码/i.test([el.id,el.name,el.placeholder].join(' '));});
 if(liveFields.length>=2)return null;
 // Ignore hidden templates, floating helpers and transient notification messages.
 var visibleMarker=Array.prototype.some.call(document.querySelectorAll('h1,h2,h3,h4,p,div,span,strong'),function(el){var t=clean(el.innerText);var rx=/^(预约已受理|预约申请已受理|预约成功|预约申请成功|预约提交成功)$/;return !el.closest('[role=alert],.toast,.el-message,.el-notification,#sx-app-float,#jn-float,.sx-toast')&&el.getClientRects().length>0&&(rx.test(t)||Array.prototype.some.call(el.childNodes,function(n){return n.nodeType===3&&rx.test(clean(n.nodeValue));}));});
 return visibleMarker?result:null;
};
async function scan(){
 if(inFlight)return;
 var bank=window.shuixian&&window.shuixian.detect();if(!bank||!['ABC','BOC','CCB','PSBC','ICBC'].includes(bank.id))return;
 var result=api.readResult();if(!result)return;
 var fingerprint=JSON.stringify([result.id,result.phone,result.product,result.branch,result.date,result.status]);if(done[fingerprint])return;
 if(Date.now()<(nextAttempt[fingerprint]||0))return;
 inFlight=true;
 try{
  var person=identify(result,await people());if(!person){notify('已检测到预约成功，人员无法唯一匹配，未上报');return;}
  var payload={id_card:person.id_card,name:person.name,phone:person.phone,bank_code:bank.id,status:result.status,bank_status:result.bank_status||(result.status==='accepted'?'预约已受理，待核查':'预约成功'),product:result.product,branch:result.branch,address:result.address||'',exchange_date:result.date||'',quantity:result.quantity||'',page_url:location.origin+location.pathname};
  tries[fingerprint]=(tries[fingerprint]||0)+1;
  var response=await new Promise(function(resolve){var timeout=setTimeout(function(){resolve(null);},35000);try{chrome.runtime.sendMessage({type:'reservationReport',reservation:payload},function(r){clearTimeout(timeout);resolve(r);});}catch(e){clearTimeout(timeout);resolve(null);}});
  if(response&&response.code===0){done[fingerprint]=true;notify('预约成功信息已同步后台');}
  else {notify('预约成功，后台同步未完成，将自动重试');var retryDelay=Math.min(60000,tries[fingerprint]*10000);nextAttempt[fingerprint]=Date.now()+retryDelay;setTimeout(scan,retryDelay+50);}
 }catch(e){notify('预约成功，后台同步暂不可用');nextAttempt[fingerprint]=Date.now()+60000;setTimeout(scan,60050);}finally{inFlight=false;}
}
api.scan=scan;
if(document.body){new MutationObserver(schedule).observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['style','class']});schedule();}
window.addEventListener('pageshow',schedule);window.addEventListener('online',schedule);
})();
