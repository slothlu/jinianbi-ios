import Foundation
import CryptoKit

/// Persist before acknowledging the WebView. Successful server ACKs remove only that revision.
final class ReservationQueue {
    static let shared = ReservationQueue()
    private let worker = DispatchQueue(label: "lumian.reservation.outbox")
    private var timer: DispatchSourceTimer?
    private var sending = false
    private let file: URL

    private init() {
        file = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("ReservationOutbox", isDirectory: true).appendingPathComponent("outbox.json")
    }
    private func digest(_ value: String) -> String {
        SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
    }
    private func owner() -> String {
        var part = String(LicenseStore.access().split(separator: ".").first ?? "")
        part = part.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        part += String(repeating: "=", count: (4 - part.count % 4) % 4)
        if let bytes = Data(base64Encoded: part), let value = try? JSONSerialization.jsonObject(with: bytes) as? [String: Any],
           let id = value["c"] as? NSNumber, id.intValue > 0 { return "card:\(id.intValue)" }
        return "token:" + digest(LicenseStore.token())
    }
    private func read() throws -> [[String: Any]] {
        if !FileManager.default.fileExists(atPath: file.path) { return [] }
        let data = try Data(contentsOf: file)
        guard let items = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
            throw NSError(domain: "ReservationOutbox", code: 1)
        }
        return items
    }
    private func write(_ items: [[String: Any]]) throws {
        let dir = file.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var directory = dir
        var flags = URLResourceValues(); flags.isExcludedFromBackup = true
        try directory.setResourceValues(flags)
        let data = try JSONSerialization.data(withJSONObject: items)
        try data.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    func start() {
        worker.async {
            if self.timer == nil {
                let timer = DispatchSource.makeTimerSource(queue: self.worker)
                timer.schedule(deadline: .now() + 60, repeating: 60)
                timer.setEventHandler { [weak self] in self?.flush() }
                self.timer = timer; timer.resume()
            }
            self.flush()
        }
    }
    func enqueue(_ result: [String: Any], completion: @escaping ([String: Any]) -> Void) {
        worker.async {
            do {
                let bytes = try JSONSerialization.data(withJSONObject: result)
                guard bytes.count <= 8000, !LicenseStore.token().isEmpty else { throw NSError(domain: "ReservationOutbox", code: 2) }
                let owner = self.owner()
                var key: [String] = [owner]
                for field in ["id_card", "bank_code", "product", "branch", "exchange_date", "quantity"] { key.append(String(describing: result[field] ?? "")) }
                let id = self.digest(String(data: try JSONSerialization.data(withJSONObject: key), encoding: .utf8) ?? "")
                var items = try self.read()
                let index = items.firstIndex { $0["id"] as? String == id }
                guard index != nil || items.count < 500 else { throw NSError(domain: "ReservationOutbox", code: 3) }
                var value = result
                if let index = index, let old = items[index]["reservation"] as? [String: Any],
                   old["status"] as? String == "confirmed", result["status"] as? String == "accepted" { value = old }
                let item: [String: Any] = ["id": id, "owner": owner, "reservation": value, "revision": UUID().uuidString, "attempts": 0, "nextAttempt": 0.0]
                if let index = index { items[index] = item } else { items.append(item) }
                try self.write(items)
                DispatchQueue.main.async { completion(["code": 0, "queued": true]) }
                self.flush()
            } catch { DispatchQueue.main.async { completion(["code": 1]) } }
        }
    }
    private func flush() {
        guard !sending, !LicenseStore.token().isEmpty else { return }
        do {
            let cardOwner = owner(), tokenOwner = "token:" + digest(LicenseStore.token()), now = Date().timeIntervalSince1970
            guard let entry = try read().first(where: { ($0["owner"] as? String == cardOwner || $0["owner"] as? String == tokenOwner) && ($0["nextAttempt"] as? Double ?? 0) <= now }),
                  let result = entry["reservation"] as? [String: Any] else { return }
            sending = true
            LicenseClient.reportReservation(result) { [weak self] _, _, response in
                guard let self = self else { return }
                self.worker.async {
                    defer { self.sending = false; self.worker.asyncAfter(deadline: .now() + 1) { self.flush() } }
                    do {
                        var items = try self.read()
                        guard let index = items.firstIndex(where: { $0["id"] as? String == entry["id"] as? String && $0["revision"] as? String == entry["revision"] as? String }) else { return }
                        if response?["code"] as? Int == 0 { items.remove(at: index) }
                        else {
                            let attempts = (items[index]["attempts"] as? Int ?? 0) + 1
                            items[index]["attempts"] = attempts
                            items[index]["nextAttempt"] = Date().timeIntervalSince1970 + min(3600.0, pow(2.0, Double(min(attempts, 10))) * 15.0)
                        }
                        try self.write(items)
                    } catch { /* Preserve unreadable/unacknowledged records. A later wake-up retries. */ }
                }
            }
        } catch { /* No UI changes and no destructive recovery on storage errors. */ }
    }
}
