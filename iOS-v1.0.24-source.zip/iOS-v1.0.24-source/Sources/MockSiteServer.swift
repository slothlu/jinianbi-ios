import Foundation
import Network

/// Serves only bundled simulator resources on IPv4 loopback. Never forwards or stores submitted data.
final class MockSiteServer {
    private var listener: NWListener?
    private let queue = DispatchQueue(label: "lumian.mock.loopback")
    private(set) var origin: URL?
    private let root: URL
    init?(bundle: Bundle = .main) {
        guard let folder = bundle.url(forResource: "mock", withExtension: nil) else { return nil }
        let site = folder.appendingPathComponent("icbc", isDirectory: true)
        guard FileManager.default.fileExists(atPath: site.appendingPathComponent("ICBC/ICBCCOIN/roccentryPC.html").path) else { return nil }
        root = site.standardizedFileURL
    }
    func start(_ completion: @escaping (URL?) -> Void) {
        if let origin = origin { completion(origin); return }
        if listener != nil { return } // A pending start will finish the original request.
        do {
            let parameters = NWParameters.tcp
            parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
            let server = try NWListener(using: parameters)
            listener = server
            server.newConnectionHandler = { [weak self] connection in
                connection.start(queue: self?.queue ?? .global())
                self?.receive(connection, Data())
            }
            server.stateUpdateHandler = { [weak self, weak server] state in
                switch state {
                case .ready:
                    guard let self = self, let port = server?.port else { return }
                    self.origin = URL(string: "http://127.0.0.1:\(port.rawValue)")
                    DispatchQueue.main.async { completion(self.origin) }
                case .failed: self?.listener = nil; DispatchQueue.main.async { completion(nil) }
                default: break
                }
            }
            server.start(queue: queue)
        } catch { completion(nil) }
    }
    func contains(_ url: URL?) -> Bool {
        guard let url = url, let origin = origin else { return false }
        return url.scheme == "http" && url.host == "127.0.0.1" && url.port == origin.port
    }
    private func receive(_ connection: NWConnection, _ pending: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] chunk, _, done, error in
            guard let self = self else { connection.cancel(); return }
            var data = pending; if let chunk = chunk { data.append(chunk) }
            guard data.count <= 278528 else { self.reply(connection, 413); return }
            guard let end = data.range(of: Data("\r\n\r\n".utf8)) else {
                if data.count > 16384 || done || error != nil { self.reply(connection, 400) } else { self.receive(connection, data) }; return
            }
            guard end.upperBound <= 16384, let headers = String(data: data[..<end.lowerBound], encoding: .isoLatin1) else { self.reply(connection, 400); return }
            let lines = headers.components(separatedBy: "\r\n")
            let first = (lines.first ?? "").split(separator: " ")
            guard first.count >= 2, ["GET", "POST", "HEAD"].contains(String(first[0])) else { self.reply(connection, 405); return }
            var length = 0
            for line in lines.dropFirst() {
                let lower = line.lowercased()
                if lower.hasPrefix("transfer-encoding:") { self.reply(connection, 400); return }
                if lower.hasPrefix("content-length:") {
                    guard let count = Int(line.dropFirst(15).trimmingCharacters(in: .whitespaces)), count >= 0, count <= 262144 else { self.reply(connection, 413); return }
                    length = count
                }
            }
            if data.count - end.upperBound < length {
                if done || error != nil { connection.cancel() } else { self.receive(connection, data) }; return
            }
            // The body is intentionally discarded. Responses come only from supplied mock fixtures.
            let raw = String(first[1]).components(separatedBy: "?")[0]
            guard let path = raw.removingPercentEncoding, path.hasPrefix("/"), !path.contains("\\"), !path.contains("\0"), !path.split(separator: "/").contains("..") else { self.reply(connection, 403); return }
            let relative = String(path.dropFirst()) + (path.hasSuffix("/") ? "index.html" : "")
            for suffix in ["", ".html"] {
                let file = self.root.appendingPathComponent(relative + suffix).standardizedFileURL
                guard file.path.hasPrefix(self.root.path + "/") else { self.reply(connection, 403); return }
                if let bytes = try? Data(contentsOf: file) { self.reply(connection, 200, self.mime(file.pathExtension), bytes, first[0] == "HEAD"); return }
            }
            self.reply(connection, 404)
        }
    }
    private func mime(_ ext: String) -> String {
        switch ext.lowercased() {
        case "html": return "text/html; charset=utf-8"
        case "js": return "application/javascript"
        case "css": return "text/css"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "gif": return "image/gif"
        case "svg": return "image/svg+xml"
        case "ico": return "image/x-icon"
        case "woff": return "font/woff"
        default: return "text/plain; charset=utf-8"
        }
    }
    private func reply(_ connection: NWConnection, _ status: Int, _ mime: String = "text/plain", _ body: Data = Data(), _ head: Bool = false) {
        var response = Data("HTTP/1.1 \(status) \(status == 200 ? "OK" : "Error")\r\nContent-Type: \(mime)\r\nContent-Length: \(body.count)\r\nCache-Control: no-store\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n\r\n".utf8)
        if !head { response.append(body) }
        connection.send(content: response, completion: .contentProcessed { _ in connection.cancel() })
    }
    deinit { listener?.stateUpdateHandler = nil; listener?.cancel() }
}
