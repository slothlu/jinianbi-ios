/**
 * 路面纪念钞币科技 · 中国工商银行（ICBC）适配器
 * element-ui 增强型：
 *   ① 基础字段（地址缺省用省市区拼接）+ 证件类型
 *   ② 数量 → 兑换日期
 *   ③ 省 / 市 / 区 / 网点 独立 el-select（全局 placeholder 匹配，匹配不到不退回）
 *   ④ 三级回退：分段 el-select → BranchFinder 省/市/网点 → 网点输入框直写
 *   ⑤ 协议勾选；提交文案兜底含“下一步”
 */
(function () {
  "use strict";
  const C = window.__SX_COMMON__;

  const adapter = {
    id: "ICBC",
    detect: () => (location.hostname || "").includes("icbc") || /ICBCCOIN|ICBCDynamicSite|roccentry/i.test(location.pathname) || !!document.querySelector('script[src*="ICBCCOIN"]'),

    async waitForOpen() { },

    getSelectorMap: () => ({
      fullName: "#custName, input[name=\"custName\"]",
      idType: "#idType, select[name=\"idType\"]",
      idNumber: "#idNo, input[name=\"idNo\"]",
      mobile: "#mobile, input[name=\"mobile\"]",
      address: "#address, textarea[name=\"address\"]",
      zipCode: "#zip, input[name=\"zip\"]",
      province: "select#province",
      city: "select#city",
      district: "select#district",
      submitButton: "button#submit, button.btn-submit, .submit"
    }),

    findInputByKeywords(key) {
      const kw = {
        fullName: ["姓名", "客户姓名", "兑换人"],
        idNumber: ["证件号码", "证件号", "身份证"],
        mobile: ["手机号", "手机号码", "联系电话"],
        address: ["联系地址", "详细地址", "通讯地址"],
        branch: ["网点", "兑换网点", "选择网点"]
      };
      const words = kw[key];
      if (!words) return null;
      for (const el of document.querySelectorAll("input, textarea")) {
        if (!C.isVisible(el) || el.readOnly) continue;
        const hay = C.esc(
          (el.getAttribute("placeholder") || "") + "|" + (el.getAttribute("aria-label") || "") + "|" +
          (el.name || "") + "|" + (el.id || "") + "|" + (el.closest("label") ? C.esc(el.closest("label").textContent) : "")
        );
        if (words.some((w) => hay.indexOf(C.esc(w)) >= 0)) return el;
      }
      return null;
    },

    // 数量输入框：placeholder/name/id 关键词 + number/max 兜底
    findQuantityInput() {
      return C.findQuantityInput();
    },

    // 省 / 市 / 区 / 网点 独立 el-select（全局 placeholder 匹配，不退回第一个）
    // Use the dropdown owned by this select, never the first visible dropdown on the page.
    async fillICBCBranchSelectors(source) {
      const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
      const visible=el=>!!el&&C.isVisible(el);
      const clean=value=>String(value||'').replace(/[\s\u3000]/g,'').replace(/（/g,'(').replace(/）/g,')').replace(/^(?:中国工商银行(?:股份有限公司)?|工商银行|工行)/,'');
      // Prefer exact names. Administrative aliases are only accepted when the match is unique.
      const region=value=>clean(value).replace(/(?:省分行|市分行|自治区|特别行政区|自治州|地区|分行|省|市|区|县)+$/,'');
      const person=Object.assign({},source||{});
      const path=String(person.branchPath||(String(person.branch||'').includes('/')?person.branch:'')).split('/').map(v=>v.trim()).filter(Boolean);
      if(path.length>=3){person.province=person.province||path[0];person.city=person.city||path[1];if(path.length>=4)person.district=person.district||path[2];person.branch=path[path.length-1];}
      if(!person.branch)return {success:false,message:'请先填写兑换网点名称'};
      const steps=[
        {key:'province',words:['省份','请选择省'],native:'select#province,select[name="province"]'},
        {key:'city',words:['城市','地市','请选择市'],native:'select#city,select[name="city"]'},
        {key:'district',words:['区县','县区','区域','请选择区','请选择县'],native:'select#district,select[name="district"],select[name="county"]',optional:true},
        {key:'branch',words:['网点'],native:'select#branch,select#internetSite,select[name="internetSite"],select[name="branch"]'}
      ];
      const find=step=>Array.from(document.querySelectorAll('.el-select input,'+step.native)).find(el=>visible(el)&&(el.tagName==='SELECT'||step.words.some(word=>(el.placeholder||'').includes(word))));
      const popup=input=>{
        if(!input||input.tagName==='SELECT')return null;
        const id=input.getAttribute('aria-controls')||input.getAttribute('aria-owns'),own=input.closest('.el-select');
        return (id&&document.getElementById(id))||(own&&own.querySelector('.el-select-dropdown'));
      };
      const options=input=>{
        if(input.tagName==='SELECT')return Array.from(input.options).filter(o=>o.value&&!o.disabled&&!o.closest('optgroup[disabled]'));
        const menu=popup(input);
        return menu&&visible(menu)?Array.from(menu.querySelectorAll('.el-select-dropdown__item,[role="option"]')).filter(o=>visible(o)&&!o.classList.contains('is-disabled')&&o.getAttribute('aria-disabled')!=='true'):[];
      };
      const close=input=>{if(input&&input.tagName!=='SELECT'&&visible(popup(input)))input.click();};
      if(!find(steps[0])){
        // On the supplied site this switch is a span, not a button or anchor.
        const switcher=Array.from(document.querySelectorAll('.keyWordQuery,button,a,[role="button"],span')).find(el=>visible(el)&&/^(按分行查询|按地区查询|按区域查询)$/.test((el.textContent||'').trim()));
        if(switcher){switcher.click();await pause(100);}
      }
      for(const step of steps){
        let input=find(step),value=person[step.key],chosen=null;
        const deadline=Date.now()+6000;
        do{
          input=find(step);
          if(!input){if(step.optional)break;await pause(100);continue;}
          if(input.disabled){await pause(100);continue;}
          if(!value&&!step.optional)return {success:false,message:'请补充'+step.words[0]+'后重试'};
          // Do not toggle an already open dropdown closed.
          if(input.tagName!=='SELECT'&&!visible(popup(input))){input.scrollIntoView({block:'nearest'});input.click();await pause(100);}
          const list=options(input);
          if(!value&&step.key==='district'&&list.length){
            const hits=list.filter(o=>{const name=region(o.textContent);return name.length>=2&&clean(person.branch).includes(name);});
            if(hits.length===1)value=hits[0].textContent.trim();
            else if(list.length===1)value=list[0].textContent.trim();
            else{close(input);return {success:false,message:'无法从网点名称唯一确定区县，请补充区县后重试'};}
          }
          let hits=list.filter(o=>clean(o.textContent)===clean(value));
          if(!hits.length&&step.key!=='branch')hits=list.filter(o=>region(o.textContent)===region(value)&&region(value));
          if(!hits.length&&step.key==='branch'&&clean(value).length>=2)hits=list.filter(o=>clean(o.textContent).includes(clean(value)));
          if(hits.length>1){close(input);return {success:false,message:step.words[0]+'存在多个匹配，请填写完整名称'};}
          if(hits.length===1){chosen=hits[0];break;}
          await pause(100);
        }while(Date.now()<deadline);
        if(!input&&step.optional)continue;
        if(!chosen){close(input);return {success:false,message:'未找到可选择的'+step.words[0]+'：'+(value||'请先配置')};}
        const label=chosen.textContent.trim();
        if(input.tagName==='SELECT'){
          if(input.value!==chosen.value){input.value=chosen.value;input.dispatchEvent(new Event('change',{bubbles:true}));}
        }else if(input.value!==label||!chosen.classList.contains('selected')){chosen.scrollIntoView({block:'nearest'});chosen.click();}
        else close(input);
        let accepted=false;
        for(let i=0;i<40;i++){
          await pause(70);input=find(step);
          if(input&&(input.tagName==='SELECT'?input.value===chosen.value:clean(input.value)===clean(label))){accepted=true;break;}
        }
        if(!accepted){close(input);return {success:false,message:step.words[0]+'未确认选中，请重试或手动选择'};}
        await pause(80); // Allow the next field's value/options to reset before resolving it again.
      }
      return {success:true};
    },

    async fillForm(person = {}) {
      person = C.normalizePerson(person);
      const selMap = this.getSelectorMap();
      const smart = window.__SX_SMART_FIND__;
      const set = (key, val) => {
        if (val == null || val === "") return;
        let el = smart ? smart(key) : null;
        if (!el && key === "quantity") el = C.findQuantityInput();
        if (!el && selMap[key]) el = C.safeQ(selMap[key]);
        if (!el && this.findInputByKeywords) el = this.findInputByKeywords(key);
        if (el) C.fillValue(el, val);
        else console.warn("[ICBC] 未找到", key);
      };

      set("fullName", person.fullName);
      set("idNumber", person.idNumber);
      set("mobile", person.mobile);
      set("address", C.fullAddress(person));
      const idType = (smart && smart("idType")) || C.safeQ(selMap.idType);
      if (idType) C.selectIdType(idType);

      // 原生省/市/区 select（若存在）
      const branchResult = await this.fillICBCBranchSelectors(person);
      if (!branchResult.success) throw new Error(branchResult.message);

      // 数量（在日期之前）
      if (person.quantity) {
        const q = this.findQuantityInput();
        if (q) { C.fillValue(q, person.quantity); console.log("[ICBC] 预约数量填写成功:", person.quantity); }
        else console.warn("[ICBC] 未找到数量输入框");
      }

      // 兑换日期
      const date = C.normalizeExchangeDate(person.exchangeTime);
      const dateEl = C.findExchangeDateInput();
      if (date && dateEl) {
        C.fillValue(dateEl, date);
        console.log("[ICBC] 兑换日期填写成功:", date);
      } else if (person.exchangeTime) {
        console.warn("[ICBC] 未找到兑换日期输入框");
      }

      C.autoCheckAgreementCheckboxes();
      console.log("[ICBC] 表单填写完成");
      return { ok: true, bank: "ICBC" };
    },

    async submit() {
      const btn = C.safeQ('button#submit, button.btn-submit, .submit, button[type="submit"], .el-button--primary');
      if (btn && !btn.disabled) {
        btn.click();
        console.log("[ICBC] 提交按钮已点击");
        return true;
      }
      // 文案兜底：遍历 button / .el-button / .btn / [role=button]
      const words = ["提交", "确认", "下一步", "预约"];
      const candidates = document.querySelectorAll("button, .el-button, .btn, [role='button'], input[type='submit']");
      for (const b of candidates) {
        if (!C.isVisible(b) || b.disabled) continue;
        const t = C.esc(b.textContent || "") + "|" + C.esc(b.value || "");
        if (words.some((w) => t.indexOf(C.esc(w)) >= 0)) {
          b.click();
          console.log("[ICBC] 提交按钮（文案匹配）已点击");
          return true;
        }
      }
      console.warn("[ICBC] 未找到提交按钮");
      return false;
    },

    async verifyResult() {
      return C.reservationSucceeded();
    }
  };

  window.shuixian.register(adapter);
})();
