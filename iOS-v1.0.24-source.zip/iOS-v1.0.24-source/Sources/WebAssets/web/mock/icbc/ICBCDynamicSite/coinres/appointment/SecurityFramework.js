
var EBDP_SECURITYFLAG=true;
var JSP_INIT_TIME=0;
var randomNumId;
var mouseClickCount=0;
var keyClickCount=0;
var _hiddenFormIdArr=['encrytBehaviorInfos',
'randomNumId'];
if(EBDP_SECURITYFLAG){
generateJSPInitTime();
initEvent(window);
if(window.attachEvent){
window.attachEvent("onload",interceptFormSubmit);}else if(window.addEventListener){
window.addEventListener("load",interceptFormSubmit,false);}}
function resetWhenComplete(){
generateJSPInitTime();
mouseClickCount=0;
keyClickCount=0;}
function securityBeforeSend(formEl){
if(typeof(formEl)!='undefined'){
return _createSecurityFormValue(formEl);}}
function securityJsonBeforeSend(_data){
var key=createXXTEAKey2(_data.dse_sessionId);
var _dataNames='';
if(typeof(_data)!='undefined'&&typeof(_data)=='object'){
for(var _name in _data){
_dataNames+=_name+'|';}
var originJsonValue=JsonToString(_data);
var entryOriginJsonValue='';
var encrytBehaviorInfos;
if(_dataNames!=''){
_dataNames=base64encode(encryptInfos(key,_dataNames));}
if(originJsonValue!=''&&originJsonValue!=null){
entryOriginJsonValue=md5(originJsonValue);}
var behaviorInfos=getBehaviorInfos(_dataNames,entryOriginJsonValue);
encrytBehaviorInfos=encryptInfos(key,JsonToString(behaviorInfos));
_data.encrytBehaviorInfos=base64encode(encrytBehaviorInfos);
_data.randomNumId=randomNumId;}else if(typeof(_data)!='undefined'&&typeof(_data)=='string'){
var _dataHashValue='';
if(_data!=''){
_dataArr=_data.split('&');
for(var i=0;i<_dataArr.length;i++){
_dataItem=_dataArr[i];
_dataItemArr=_dataItem.split('=');
_dataNames+=_dataItemArr[0]+'|';}
_dataHashValue=md5(_data);}
if(_dataNames!=''){
_dataNames=base64encode(encryptInfos(key,_dataNames));}
var behaviorInfos=getBehaviorInfos(_dataNames,_dataHashValue);
var encrytBehaviorInfos=encryptInfos(key,JsonToString(behaviorInfos));
var _tempData="encrytBehaviorInfos="+encodeURIComponent(base64encode(encrytBehaviorInfos))+"&randomNumId="+randomNumId;
_data!=''?_data+='&'+_tempData:_data=_tempData;}
return _data;}
function _createSecurityFormValue(_tmpForm){
removeOldFormHiddenInfos(_tmpForm);
var formNames='';
var entryOriginFormValue='';
var elementsObj=_tmpForm.elements;
for(var i=0;i<elementsObj.length;i++){
var obj=elementsObj[i];
if(obj.name!=undefined&&obj.name!=""){
if(obj.disabled){
continue;}
if(obj.tagName.toLowerCase()=='input'&&obj.type.toLowerCase()=='checkbox'&&obj.checked==false){
continue;}
if(obj.tagName.toLowerCase()=='input'&&obj.type.toLowerCase()=='radio'&&obj.checked==false){
continue;}
if(obj.tagName.toLowerCase()=='select'&&obj.value==''){
continue;}
formNames+=obj.name+'|';}}
var originFormValue=formtoJson(_tmpForm);
var key=createXXTEAKey();
var encrytBehaviorInfos;
if(formNames!=''){
formNames=base64encode(encryptInfos(key,formNames));}
if(originFormValue!=''&&originFormValue!=null){
entryOriginFormValue=md5(originFormValue);}
var behaviorInfos=getBehaviorInfos(formNames,entryOriginFormValue);
encrytBehaviorInfos=encryptInfos(key,JsonToString(behaviorInfos));
var _formCreateArr=[base64encode(encrytBehaviorInfos),
randomNumId];
createFormInput(_tmpForm,_formCreateArr);
return _tmpForm;}
function createFormInput(form,_formCreateArr){
for(var i=0;i<_formCreateArr.length;i++){
var aElement=document.createElement("input");
aElement.name=_hiddenFormIdArr[i];
aElement.id=_hiddenFormIdArr[i];
aElement.type="hidden";
aElement.value=_formCreateArr[i];
form.appendChild(aElement);}}
function removeOldFormHiddenInfos(form){
for(var i=0;i<_hiddenFormIdArr.length;i++){
var _oldInput=document.getElementById(_hiddenFormIdArr[i]);
if(typeof(_oldInput)!='undefined'&&_oldInput!=null){
form.removeChild(_oldInput);}}}
function getBehaviorInfos(formNames,formHashValue){
var behaviorInfos={
'formNames':formNames,
'survivalTime':getSurvivalTime(),
'clickTimes':getMouseClickCount(),
'keyboardTimes':getKeyClickCount(),
'screenSize':getDocSize(window),
'cssAbility':cssIsRendered(),
'formHashValue':formHashValue};
return behaviorInfos;}
function createXXTEAKey2(sessionId){
var randomNum=Math.random()*10000;
randomNumId=randomNum;
var dse_sessionId=sessionId;
var _tempRandomNum=randomNum.toString().substring(1,3)+dse_sessionId.substring(2,5)+randomNum.toString().substring(2,4)+dse_sessionId.substring(4,7);
var md5code=md5(_tempRandomNum);
var key=md5code.substring(3,9);
return key;}
function createXXTEAKey(){
var randomNum=Math.random()*10000;
randomNumId=randomNum;
var dse_sessionId='';
var sessions=document.getElementsByName('dse_sessionId');
for(var i=0;i<sessions.length;i++){
dse_sessionId=sessions[i].value;}
var _tempRandomNum=randomNum.toString().substring(1,3)+dse_sessionId.substring(2,5)+randomNum.toString().substring(2,4)+dse_sessionId.substring(4,7);
var md5code=md5(_tempRandomNum);
var key=md5code.substring(3,9);
return key;}
function encryptInfos(key,behaviorInfos){
var xxteaValue=xxtea_encrypt(utf16to8(behaviorInfos),key);
return xxteaValue;}
function decryptBehaviorInfos(key,behaviorInfos){
var xxteaValue=utf8to16(xxtea_decrypt(behaviorInfos,key));
return xxteaValue;}
function interceptFormSubmit(){
var oldSubmit;
var forms=document.forms;
for(var i=0;i<forms.length;i++){
var _form=forms[i];
if(_form!=null&&_form!='undefined'){
_form.oldSubmit=_form.submit;
_form.submit=function(){
var _tmpForm=this;
_createSecurityFormValue(_tmpForm);
_tmpForm.oldSubmit();};}}}
function initEvent(win){
initMouseClickEvent(win);
initKeyClickEvent(win);}
function initMouseClickEvent(win){
if(!win.document){
return;}
win.document.onmouseup=function(){
mouseClickCount++;};}
function initKeyClickEvent(win){
if(!win.document){
return;}
win.document.onkeydown=function(){
keyClickCount++;};}
function getMouseClickCount(){
if(typeof(mouseClickCount)=="number"){
return mouseClickCount;}
return 0;}
function getKeyClickCount(){
if(typeof(keyClickCount)=="number"){
return keyClickCount;}
return 0;}
function getDocSize(window){
try{
if(window==null){
return;}
var height=document.body.clientHeight;
var width=document.body.clientWidth;
var tmp=height+'*'+width;
return tmp;}catch(e){
ctp.core.log.err(e.message);}}
function cssIsRendered(){
try{
var targetElements=jQuery("body");
var element=document.createElement('DIV');
element.setAttribute("style","display: none");
element.setAttribute("id","test123");
targetElements[0].appendChild(element);
if(targetElements[0].style.display.indexOf("none")!=-1){
targetElements[0].removeAttribute("style","display: none");}
var temp=jQuery("#test123");
temp.css("align","center");
if(temp.get(0).style!=null&&temp.get(0).style.align=='center'){
targetElements[0].removeChild(element);
return 'true';}else{
return 'false';}}catch(e){}}
function getSurvivalTime(){
var end=new Date();
var before_submit_time=end.getTime();
return before_submit_time-JSP_INIT_TIME;}
function generateJSPInitTime(){
var start=new Date();
JSP_INIT_TIME=start.getTime();}
function securityWhenComplete(){
generateJSPInitTime();}
var hexcase=1;
var b64pad="";
var chrsz=8;
var mode=32;
function preprocess(form){
var str="";
str+=form.verifycode.value;
str=str.toUpperCase();
form.p.value=md5(md5_3(form.p.value)+str);
return true;}
function md5_3(s){
var tmp=new Array;
tmp=core_md5(str2binl(s),s.length*chrsz);
tmp=core_md5(tmp,16*chrsz);
tmp=core_md5(tmp,16*chrsz);
return binl2hex(tmp);}
function md5(s){
return hex_md5(s);}
function hex_md5(s){
return binl2hex(core_md5(str2binl(s),s.length*chrsz));}
function b64_md5(s){
return binl2b64(core_md5(str2binl(s),s.length*chrsz));}
function str_md5(s){
return binl2str(core_md5(str2binl(s),s.length*chrsz));}
function hex_hmac_md5(key,data){
return binl2hex(core_hmac_md5(key,data));}
function b64_hmac_md5(key,data){
return binl2b64(core_hmac_md5(key,data));}
function str_hmac_md5(key,data){
return binl2str(core_hmac_md5(key,data));}
function md5_vm_test(){
return hex_md5("abc")=="900150983cd24fb0d6963f7d28e17f72";}
function core_md5(x,len){
x[len>>5]|=0x80<<((len)%32);
x[(((len+64)>>>9)<<4)+14]=len;
var a=1732584193;
var b=-271733879;
var c=-1732584194;
var d=271733878;
for(var i=0;i<x.length;i+=16){
var olda=a;
var oldb=b;
var oldc=c;
var oldd=d;
a=md5_ff(a,b,c,d,x[i+0],7,-680876936);
d=md5_ff(d,a,b,c,x[i+1],12,-389564586);
c=md5_ff(c,d,a,b,x[i+2],17,606105819);
b=md5_ff(b,c,d,a,x[i+3],22,-1044525330);
a=md5_ff(a,b,c,d,x[i+4],7,-176418897);
d=md5_ff(d,a,b,c,x[i+5],12,1200080426);
c=md5_ff(c,d,a,b,x[i+6],17,-1473231341);
b=md5_ff(b,c,d,a,x[i+7],22,-45705983);
a=md5_ff(a,b,c,d,x[i+8],7,1770035416);
d=md5_ff(d,a,b,c,x[i+9],12,-1958414417);
c=md5_ff(c,d,a,b,x[i+10],17,-42063);
b=md5_ff(b,c,d,a,x[i+11],22,-1990404162);
a=md5_ff(a,b,c,d,x[i+12],7,1804603682);
d=md5_ff(d,a,b,c,x[i+13],12,-40341101);
c=md5_ff(c,d,a,b,x[i+14],17,-1502002290);
b=md5_ff(b,c,d,a,x[i+15],22,1236535329);
a=md5_gg(a,b,c,d,x[i+1],5,-165796510);
d=md5_gg(d,a,b,c,x[i+6],9,-1069501632);
c=md5_gg(c,d,a,b,x[i+11],14,643717713);
b=md5_gg(b,c,d,a,x[i+0],20,-373897302);
a=md5_gg(a,b,c,d,x[i+5],5,-701558691);
d=md5_gg(d,a,b,c,x[i+10],9,38016083);
c=md5_gg(c,d,a,b,x[i+15],14,-660478335);
b=md5_gg(b,c,d,a,x[i+4],20,-405537848);
a=md5_gg(a,b,c,d,x[i+9],5,568446438);
d=md5_gg(d,a,b,c,x[i+14],9,-1019803690);
c=md5_gg(c,d,a,b,x[i+3],14,-187363961);
b=md5_gg(b,c,d,a,x[i+8],20,1163531501);
a=md5_gg(a,b,c,d,x[i+13],5,-1444681467);
d=md5_gg(d,a,b,c,x[i+2],9,-51403784);
c=md5_gg(c,d,a,b,x[i+7],14,1735328473);
b=md5_gg(b,c,d,a,x[i+12],20,-1926607734);
a=md5_hh(a,b,c,d,x[i+5],4,-378558);
d=md5_hh(d,a,b,c,x[i+8],11,-2022574463);
c=md5_hh(c,d,a,b,x[i+11],16,1839030562);
b=md5_hh(b,c,d,a,x[i+14],23,-35309556);
a=md5_hh(a,b,c,d,x[i+1],4,-1530992060);
d=md5_hh(d,a,b,c,x[i+4],11,1272893353);
c=md5_hh(c,d,a,b,x[i+7],16,-155497632);
b=md5_hh(b,c,d,a,x[i+10],23,-1094730640);
a=md5_hh(a,b,c,d,x[i+13],4,681279174);
d=md5_hh(d,a,b,c,x[i+0],11,-358537222);
c=md5_hh(c,d,a,b,x[i+3],16,-722521979);
b=md5_hh(b,c,d,a,x[i+6],23,76029189);
a=md5_hh(a,b,c,d,x[i+9],4,-640364487);
d=md5_hh(d,a,b,c,x[i+12],11,-421815835);
c=md5_hh(c,d,a,b,x[i+15],16,530742520);
b=md5_hh(b,c,d,a,x[i+2],23,-995338651);
a=md5_ii(a,b,c,d,x[i+0],6,-198630844);
d=md5_ii(d,a,b,c,x[i+7],10,1126891415);
c=md5_ii(c,d,a,b,x[i+14],15,-1416354905);
b=md5_ii(b,c,d,a,x[i+5],21,-57434055);
a=md5_ii(a,b,c,d,x[i+12],6,1700485571);
d=md5_ii(d,a,b,c,x[i+3],10,-1894986606);
c=md5_ii(c,d,a,b,x[i+10],15,-1051523);
b=md5_ii(b,c,d,a,x[i+1],21,-2054922799);
a=md5_ii(a,b,c,d,x[i+8],6,1873313359);
d=md5_ii(d,a,b,c,x[i+15],10,-30611744);
c=md5_ii(c,d,a,b,x[i+6],15,-1560198380);
b=md5_ii(b,c,d,a,x[i+13],21,1309151649);
a=md5_ii(a,b,c,d,x[i+4],6,-145523070);
d=md5_ii(d,a,b,c,x[i+11],10,-1120210379);
c=md5_ii(c,d,a,b,x[i+2],15,718787259);
b=md5_ii(b,c,d,a,x[i+9],21,-343485551);
a=safe_add(a,olda);
b=safe_add(b,oldb);
c=safe_add(c,oldc);
d=safe_add(d,oldd);}
if(mode==16){
return Array(b,c);}else{
return Array(a,b,c,d);}}
function md5_cmn(q,a,b,x,s,t){
return safe_add(bit_rol(safe_add(safe_add(a,q),safe_add(x,t)),s),b);}
function md5_ff(a,b,c,d,x,s,t){
return md5_cmn((b&c)|((~b)&d),a,b,x,s,t);}
function md5_gg(a,b,c,d,x,s,t){
return md5_cmn((b&d)|(c&(~d)),a,b,x,s,t);}
function md5_hh(a,b,c,d,x,s,t){
return md5_cmn(b^c^d,a,b,x,s,t);}
function md5_ii(a,b,c,d,x,s,t){
return md5_cmn(c^(b|(~d)),a,b,x,s,t);}
function core_hmac_md5(key,data){
var bkey=str2binl(key);
if(bkey.length>16)
bkey=core_md5(bkey,key.length*chrsz);
var ipad=Array(16),opad=Array(16);
for(var i=0;i<16;i++){
ipad[i]=bkey[i]^0x36363636;
opad[i]=bkey[i]^0x5C5C5C5C;}
var hash=core_md5(ipad.concat(str2binl(data)),512+data.length*chrsz);
return core_md5(opad.concat(hash),512+128);}
function safe_add(x,y){
var lsw=(x&0xFFFF)+(y&0xFFFF);
var msw=(x>>16)+(y>>16)+(lsw>>16);
return(msw<<16)|(lsw&0xFFFF);}
function bit_rol(num,cnt){
return(num<<cnt)|(num>>>(32-cnt));}
function str2binl(str){
var bin=Array();
var mask=(1<<chrsz)-1;
for(var i=0;i<str.length*chrsz;i+=chrsz)
bin[i>>5]|=(str.charCodeAt(i/chrsz)&mask)<<(i%32);
return bin;}
function binl2str(bin){
var str="";
var mask=(1<<chrsz)-1;
for(var i=0;i<bin.length*32;i+=chrsz)
str+=String.fromCharCode((bin[i>>5]>>>(i%32))&mask);
return str;}
function binl2hex(binarray){
var hex_tab=hexcase?"0123456789ABCDEF":"0123456789abcdef";
var str="";
for(var i=0;i<binarray.length*4;i++){
str+=hex_tab.charAt((binarray[i>>2]>>((i%4)*8+4))&0xF)+hex_tab.charAt((binarray[i>>2]>>((i%4)*8))&0xF);}
return str;}
function binl2b64(binarray){
var tab="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var str="";
for(var i=0;i<binarray.length*4;i+=3){
var triplet=(((binarray[i>>2]>>8*(i%4))&0xFF)<<16)|(((binarray[i+1>>2]>>8*((i+1)%4))&0xFF)<<8)|((binarray[i+2>>2]>>8*((i+2)%4))&0xFF);
for(var j=0;j<4;j++){
if(i*8+j*6>binarray.length*32)
str+=b64pad;
else
str+=tab.charAt((triplet>>6*(3-j))&0x3F);}}
return str;}
function long2str(v,w){
var vl=v.length;
var n=(vl-1)<<2;
if(w){
var m=v[vl-1];
if((m<n-3)||(m>n))
return null;
n=m;}
for(var i=0;i<vl;i++){
v[i]=String.fromCharCode(v[i]&0xff,v[i]>>>8&0xff,
v[i]>>>16&0xff,v[i]>>>24&0xff);}
if(w){
return v.join('').substring(0,n);}else{
return v.join('');}}
function str2long(s,w){
var len=s.length;
var v=[];
for(var i=0;i<len;i+=4){
v[i>>2]=s.charCodeAt(i)|s.charCodeAt(i+1)<<8|s.charCodeAt(i+2)<<16|s.charCodeAt(i+3)<<24;}
if(w){
v[v.length]=len;}
return v;}
function xxtea_encrypt(str,key){
if(str==""){
return "";}
var v=str2long(str,true);
var k=str2long(key,false);
if(k.length<4){
k.length=4;}
var n=v.length-1;
var z=v[n],y=v[0],delta=0x9E3779B9;
var mx,e,p,q=Math.floor(6+52/(n+1)),sum=0;
while(0<q--){
sum=sum+delta&0xffffffff;
e=sum>>>2&3;
for(p=0;p<n;p++){
y=v[p+1];
mx=(z>>>5^y<<2)+(y>>>3^z<<4)^(sum^y)+(k[p&3^e]^z);
z=v[p]=v[p]+mx&0xffffffff;}
y=v[0];
mx=(z>>>5^y<<2)+(y>>>3^z<<4)^(sum^y)+(k[p&3^e]^z);
z=v[n]=v[n]+mx&0xffffffff;}
return long2str(v,false);}
function xxtea_decrypt(str,key){
if(str==""){
return "";}
var v=str2long(str,false);
var k=str2long(key,false);
if(k.length<4){
k.length=4;}
var n=v.length-1;
var z=v[n-1],y=v[0],delta=0x9E3779B9;
var mx,e,p,q=Math.floor(6+52/(n+1)),sum=q*delta&0xffffffff;
while(sum!=0){
e=sum>>>2&3;
for(p=n;p>0;p--){
z=v[p-1];
mx=(z>>>5^y<<2)+(y>>>3^z<<4)^(sum^y)+(k[p&3^e]^z);
y=v[p]=v[p]-mx&0xffffffff;}
z=v[n];
mx=(z>>>5^y<<2)+(y>>>3^z<<4)^(sum^y)+(k[p&3^e]^z);
y=v[0]=v[0]-mx&0xffffffff;
sum=sum-delta&0xffffffff;}
return long2str(v,true);}
function utf16to8(str){
var out,i,len,c;
out=[];
len=str.length;
for(i=0;i<len;i++){
c=str.charCodeAt(i);
if((c>=0x0001)&&(c<=0x007F)){
out[i]=str.charAt(i);}else if(c>0x07FF){
out[i]=String.fromCharCode(0xE0|((c>>12)&0x0F),
0x80|((c>>6)&0x3F),0x80|((c>>0)&0x3F));}else{
out[i]=String.fromCharCode(0xC0|((c>>6)&0x1F),
0x80|((c>>0)&0x3F));}}
return out.join('');}
function utf8to16(str){
var out,i,len,c;
var char2,char3;
out=[];
len=str.length;
i=0;
while(i<len){
c=str.charCodeAt(i++);
switch(c>>4){
case 0:
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
out[out.length]=str.charAt(i-1);
break;
case 12:
case 13:
char2=str.charCodeAt(i++);
out[out.length]=String.fromCharCode(((c&0x1F)<<6)|(char2&0x3F));
break;
case 14:
char2=str.charCodeAt(i++);
char3=str.charCodeAt(i++);
out[out.length]=String.fromCharCode(((c&0x0F)<<12)|((char2&0x3F)<<6)|((char3&0x3F)<<0));
break;}}
return out.join('');}
var base64EncodeChars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var base64DecodeChars=new Array(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,
63,52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,-1,
0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,
20,21,22,23,24,25,-1,-1,-1,-1,-1,-1,26,27,28,29,30,31,
32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,
50,51,-1,-1,-1,-1,-1);
function base64encode(str){
var out,i,len;
var c1,c2,c3;
len=str.length;
i=0;
out="";
while(i<len){
c1=str.charCodeAt(i++)&0xff;
if(i==len){
out+=base64EncodeChars.charAt(c1>>2);
out+=base64EncodeChars.charAt((c1&0x3)<<4);
out+="==";
break;}
c2=str.charCodeAt(i++);
if(i==len){
out+=base64EncodeChars.charAt(c1>>2);
out+=base64EncodeChars.charAt(((c1&0x3)<<4)|((c2&0xF0)>>4));
out+=base64EncodeChars.charAt((c2&0xF)<<2);
out+="=";
break;}
c3=str.charCodeAt(i++);
out+=base64EncodeChars.charAt(c1>>2);
out+=base64EncodeChars.charAt(((c1&0x3)<<4)|((c2&0xF0)>>4));
out+=base64EncodeChars.charAt(((c2&0xF)<<2)|((c3&0xC0)>>6));
out+=base64EncodeChars.charAt(c3&0x3F);}
return out;}
function base64decode(str){
var c1,c2,c3,c4;
var i,len,out;
len=str.length;
i=0;
out="";
while(i<len){
do{
c1=base64DecodeChars[str.charCodeAt(i++)&0xff];}while(i<len&&c1==-1);
if(c1==-1)
break;
do{
c2=base64DecodeChars[str.charCodeAt(i++)&0xff];}while(i<len&&c2==-1);
if(c2==-1)
break;
out+=String.fromCharCode((c1<<2)|((c2&0x30)>>4));
do{
c3=str.charCodeAt(i++)&0xff;
if(c3==61)
return out;
c3=base64DecodeChars[c3];}while(i<len&&c3==-1);
if(c3==-1)
break;
out+=String.fromCharCode(((c2&0XF)<<4)|((c3&0x3C)>>2));
do{
c4=str.charCodeAt(i++)&0xff;
if(c4==61)
return out;
c4=base64DecodeChars[c4];}while(i<len&&c4==-1);
if(c4==-1)
break;
out+=String.fromCharCode(((c3&0x03)<<6)|c4);}
return out;}
function formtoJson(formObj){
var paramObject=new Object();
if(formObj){
var elementsObj=formObj.elements;
var obj;
if(elementsObj){
for(var i=0;i<elementsObj.length;i+=1){
obj=elementsObj[i];
if(obj.name!=undefined&&obj.name!=""){
if(obj.disabled){
continue;}
if(obj.tagName.toLowerCase()=='input'&&obj.type.toLowerCase()=='checkbox'&&obj.checked==false){
continue;}
if(obj.tagName.toLowerCase()=='input'&&obj.type.toLowerCase()=='radio'&&obj.checked==false){
continue;}
if(obj.tagName.toLowerCase()=='select'&&obj.value==''){
continue;}
paramObject[obj.name]=obj.value;}}}else{
alert("û��elements����!");
return;}}else{
alert("form������!");
return;}
return JsonToString(paramObject);}
function JsonToString(o){
var arr=[];
var fmt=function(s){
if(typeof s=='object'&&s!=null)
return JsonToString(s);
return/^(string|number)$/.test(typeof s)?"'"+s+"'":s;}
for(var i in o)
arr.push("'"+i+"':"+fmt(o[i]));
return '{'+arr.join(',')+'}';}
