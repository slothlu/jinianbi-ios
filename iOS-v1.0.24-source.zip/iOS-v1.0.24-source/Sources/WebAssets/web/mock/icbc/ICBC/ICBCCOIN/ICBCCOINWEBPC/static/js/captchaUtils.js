/**
 * 图形验证码工具集
 * 提供两个方法：
 *   1. generateRandomCode()    - 生成4位数字+字母混合随机字符串（排除易混淆字符）
 *   2. generateCaptchaImage(code) - 根据传入字符串生成 Canvas 绘制的验证码图片，返回 data:image/png;base64,... 格式
 *
 * 使用方式：
 *   CaptchaUtils.generateRandomCode()           // => "A3k9"
 *   CaptchaUtils.generateCaptchaImage("A3k9")   // => "data:image/png;base64,iVBORw0KGgo..."
 */
(function(global) {
    'use strict';

    // 排除易混淆字符：0/O、1/I/l、2/Z、5/S
    var CHARS = '346789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz';

    /**
     * 生成4位数字+字母混合的随机字符串
     * @returns {string} 4位随机码
     */
    function generateRandomCode() {
        var len = 4;
        var code = '';
        for (var i = 0; i < len; i++) {
            code += CHARS.charAt(Math.floor(Math.random() * CHARS.length));
        }
        return code;
    }

    /**
     * 根据传入字符串生成验证码图片（PNG 格式 base64 数据 URI）
     * 需要在浏览器环境下调用（依赖 Canvas）
     * 样式：浅灰背景 + 斜线交叉干扰 + 4 个异色倾斜字符（工行风格）
     * @param {string} code - 要绘制的验证码文本
     * @returns {string} data:image/png;base64,... 格式字符串
     */
    function generateCaptchaImage(code) {
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');

        var width = 110;
        var height = 36;
        canvas.width = width;
        canvas.height = height;

        // 1. 背景：均匀浅灰
        ctx.fillStyle = '#e8e8e8';
        ctx.fillRect(0, 0, width, height);

        // 2. 干扰线：4 条左右斜线交叉（偏暗红/灰）
        var lineColors = ['#8a5a5a', '#6b6b6b', '#7a4848', '#5a5a5a'];
        var lineCount = 4;
        for (var i = 0; i < lineCount; i++) {
            ctx.beginPath();
            ctx.strokeStyle = lineColors[i % lineColors.length];
            ctx.lineWidth = 1;
            var x1 = Math.random() * width;
            var y1 = Math.random() * height;
            var x2 = Math.random() * width;
            var y2 = Math.random() * height;
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
        }

        // 3. 字符颜色池（模拟工行验证码的鲜明异色风格）
        var charColors = [
            '#1e5fa8',   // 蓝
            '#c7202f',   // 红
            '#157a3a',   // 绿
            '#a87b0d',   // 棕黄
            '#2a6fbd',   // 深蓝
            '#b4334b',   // 暗红
            '#3a8c4a',   // 浅绿
            '#c48a1a'    // 黄
        ];

        // 4. 绘制验证码文字
        var chars = code.split('');
        var charWidth = width / (chars.length + 1);
        var baseY = height * 0.72;

        chars.forEach(function(ch, idx) {
            var fontSize = 22 + Math.floor(Math.random() * 4);   // 22~25
            var fontFamily = ['Georgia, serif',
                              '"Times New Roman", serif',
                              'Arial, sans-serif',
                              '"Microsoft YaHei", sans-serif'][idx % 4];
            var x = charWidth * (idx + 0.75);
            var y = baseY + (Math.random() * 4 - 2);
            var rotate = (Math.random() * 24 - 12) * Math.PI / 180;  // -12° ~ +12°

            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(rotate);
            ctx.font = 'bold ' + fontSize + 'px ' + fontFamily;
            ctx.fillStyle = charColors[idx % charColors.length];
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(ch, 0, 0);
            ctx.restore();
        });

        return canvas.toDataURL('image/png');
    }

    // 挂载到全局对象（与项目中 coinBookData_Cache.js、coinParamData.js 等静态文件风格一致）
    global.CaptchaUtils = {
        generateRandomCode: generateRandomCode,
        generateCaptchaImage: generateCaptchaImage
    };

})(typeof window !== 'undefined' ? window : globalThis);
