var coindata = {
	"coinIssueEDate": {
		"50": new Date(new Date().getTime() + 12*3600*1000).toISOString().replace('T', ' ').substring(0, 19)
	},
	"unbanklist": "",
	"roccEntryParamAreaList": "预约地区：北京市、天津市、山西省、内蒙古自治区、辽宁省、吉林省、上海市、江苏省、安徽省、福建省、江西省、湖北省、广东省（含深圳）、四川省、贵州省、西藏自治区、甘肃省、宁夏回族自治区、新疆维吾尔自治区",
	"provinceYL": {},
	"startm": "09:00:00",
	"modOrRemoveCue": "预约开始次日9时至预约结束日24时",
	"coinIssueSDate": {
		"50": new Date(new Date().getTime() + 8*3600*1000 + 10000).toISOString().replace('T', ' ').substring(0, 19)
	},
	"bkaccadress": "http://localhost:8080/",
	"bkUpdateOrDelEtm": 1788278399000,
	"bkSdateYL": "",
	"roccEntryParamNotice": "<ol><li>由于预约人数较多，如遇等待提示请您重试。<\/li><li>为便于您预约，请确保您的本机时间为北京时间。<\/li><li>如您已在其他商业银行预约，请勿在我行再次预约，以免产生重复预约记录导致无法通过人民银行核查。<\/li><\/ol>",
	"inbkaccadress": "http://localhost:8080/",
	"bkEtime": "2026-09-01 23:59:59",
	"bkUpdateOrDelStm": 1788224400000,
	"cointype": {
		"50": "诞辰100周年普通纪念币"
	},
	"roccDisableDevtoolSwitch": "1",
	"bkEdateYL": "",
	"icbcCaptchaFlag": "0",
	"broptstapagesw": "0",
	"bknotice": "<ul><li>预约时请输入正确的手机号码，以便正常接收相关短信通知。<\/li><li>由于预约人数较多，网点额度变化较快，请以实际预约结果为准。<\/li><\/ul>",
	"onlinePayRedirectToWAPBUrl": "https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPBAppInject?injectMenuId=rocc_coinweb_payment&injectParams=bmVlZEJhY2tGbGFnPTE=&pv_params=dHJhbnNpdGlvbmlkPVlLTDAwMTA1NDA0NjE3NjMwMDQ3NzYwMjgxNzA3JnNyY2NoYW5uZWw9Y21kbGluaw==&sourceApplication=eiop8888044043",
	"areabkamountlimit": "0",
	"arealistYL": [],
	"curtypeisbk": {
		"50": "0"
	},
	"mobileCodeFlag": "1",
	"exchsdates": {
		"50": "2026-10-13"
	},
	"nosenable": "0",
	"lmtrefreshnossw": "1",
	"bktitle": "诞辰100周年普通纪念币",
	"coinTypeUnitStr": "{\"50\":\"枚\"}",
	"coinIssueSDateYL": {},
	"coinIssueEDateYL": {},
	"exchedates": {
		"50": "2026-10-19"
	},
	"wwofficehours": "",
	"bookedNumList": [],
	"brbkamountcue": "120",
	"orderdatasourcesw": "0",
	"offlineCTHYLSwitch": "1",
	"CurrentNodeIPPort": "00239",
	"bkStime": "2026-08-31 22:00:00",
	"emdtm": "18:00:00",
	"UpdateTime": "2026-08-31 13:00:00",
	"mobileNumSegment": "134,135,136,137,138,139,147,150,151,152,157,158,159,165,1703,1705,1706,172,178,182,183,184,187,188,198,195,192,197#130,131,132,145,155,156,166,167,1704,1707,1708,1709,171,175,176,185,186,196#133,149,153,162,1700,1701,1702,173,177,180,181,189,191,199,193,190",
	"brofficetm": "广东分行@09:00:00-18:00:00#广州分行@09:00:00-18:00:00#内蒙古分行@09:00:00-18:00:00#",
	"brtype": "2",
	"businessNotes": "<div style='font-weight: bold;'>请您仔细阅读《预约兑换安排》和本须知以下内容，若您不同意或不理解任一条款或内容，请不要点击或勾选\u201c同意\u201d；您同意后，将视为您理解并接受《预约兑换安排》和本须知相关约定。<\/div><tbody><tr><td>一、诞辰100周年普通纪念币预约兑换安排<\/td><\/tr><\/tbody><div><\/div><tbody><tr><td>线上预约期：2026年8月31日22时至9月1日24时。<\/td><\/tr><tr><td>预约核实期：2026年9月4日至9月8日（网点对外营业时间）。<\/td><\/tr><tr><td>兑换期：2026年10月13日至10月19日（网点对外营业时间）。<\/td><\/tr><\/tbody><tbody><tr><td>二、<strong>按照先到先得原则办理预约，约满为止。<\/strong>预约无需注册网上银行、手机银行等即可办理。<\/td><\/tr><tr><td>三、<strong>每人预约、兑换限额为20枚。预约记录修改和撤销时间为2026年9月1日9时至24时。<\/strong><\/td><\/tr><tr><td>四、线上预约时，<strong>请录入正确的手机号码并保持手机通讯畅通，<\/strong>以便接收相关短信通知。<\/td><\/tr><tr><td>五、预约期结束后，人民银行将对全量预约记录进行核查。<strong>您可在2026年9月3日24时后通过我行线上预约渠道查询核查结果，我行也将向您预约时预留手机号码发送短信通知。未通过核查的须在核实期内前往我行任意承办预约兑换的网点办理保留兑换资格并经人民银行核实通过，方可在我行兑换。兑换期内请前往约定网点办理兑换。<\/strong><\/td><\/tr><tr><td>六、<strong>核实和兑换的有效身份证件必须为第二代居民身份证原件。<\/strong>如代他人办理须提供代办人和被代办人的第二代居民身份证原件，兑换的<strong>被代办人数不超过5人。<\/strong>由于第二代居民身份证原件遗失、未成年人未办理第二代居民身份证等原因，无法出具第二代居民身份证原件的，可以使用户口簿、临时居民身份证原件办理。<\/td><\/tr><tr><td>七、<strong>未通过人民银行核查且未办理保留兑换资格的，以及重复兑换、到非预约兑换网点或在非兑换期办理兑换的，不予受理。<\/strong><\/td><\/tr><tr><td>八、在预约兑换网点办理兑换过程中请遵守网点现场人员的引导安排。与预约有关的所有信息均以我行系统记录为准，请通过我行预约渠道查看。<\/td><\/tr><tr><td>九、<strong>您同意并授权：我行收集您的姓名、身份证号码、手机号码用于给您办理纪念币预约、核实、兑换业务，并根据监管要求，将您姓名、身份证号码信息提供人民银行进行预约记录核查。我行将依法对您的信息承担保密责任，不会超范围使用，但法律、法规和规章及其他规范性文件另有规定的除外。<\/strong><\/td><\/tr><tr><td>十、<strong>如您是不满十四周岁未成年人的监护人并使用其信息，您同意并授权：我行收集您的被监护人姓名、身份证号码、手机号码用于办理纪念币预约、核实、兑换业务，并根据监管要求，将被监护人姓名、身份证号码信息提供人民银行进行预约记录核查。我行将依法对您的被监护人信息承担保密责任，不会超范围使用，但法律、法规和规章及其他规范性文件另有规定的除外。<\/strong><\/td><\/tr><tr><td>十一、其他未尽事宜以我行官网发布的<a href='http://static.jnb.icbc.com.cn/ICBC/ICBCCOIN/exchangeAnnouncement.htm?t=260831'>《预约兑换安排》<\/a>为准。<\/td><\/tr><\/tbody>",
	"status": "0"
};
var typeArray = [
	['诞辰100周年普通纪念币', '50']
];
if(typeof coindata!=="undefined"){coindata.bkaccadress="/";coindata.inbkaccadress="/";coindata.wwwserverurl="/";coindata.ipfilterurl="/ICBCDynamicSite/coinres/";}

if(typeof coindata!=="undefined"){var trainingStart=new Date(Date.now()+8*3600000-60000).toISOString().slice(0,19).replace('T',' '),trainingEnd=new Date(Date.now()+8*3600000+86400000).toISOString().slice(0,19).replace('T',' ');Object.keys(coindata.coinIssueSDate||{}).forEach(function(k){coindata.coinIssueSDate[k]=trainingStart;});Object.keys(coindata.coinIssueEDate||{}).forEach(function(k){coindata.coinIssueEDate[k]=trainingEnd;});}
