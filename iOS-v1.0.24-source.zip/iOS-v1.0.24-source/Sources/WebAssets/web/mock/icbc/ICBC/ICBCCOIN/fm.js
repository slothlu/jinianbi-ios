/* Bundled training site: no external device-fingerprint collector. */
