if (self == top) {
    //其中self指代当前窗口对象，top指代最上层对象，如果当前对象被其他页面引用，self与top必然不相等
    document.getElementsByTagName("body")[0].style.display = 'block';//页面显示，默认body样式不显示
} else {
    //被嵌套判断top.location是否在白名单范围内，不在范围内强行跳转到错误页面
    window.location.href = 'error.html';
    //自行增加判断逻辑
}
