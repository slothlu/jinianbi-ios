var ICBCURL = window.location.origin;
