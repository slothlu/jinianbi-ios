(function () {
  'use strict';
  window.__SX_MOCK_TRAINING__ = true;
  var origin = location.origin;
  // The captured site's cosmetic random hash must not replace the mobile router's actual route.
  var replaceState = history.replaceState;
  history.replaceState = function (state, title, url) {
    if (url && /^\/ICBCCOINWEBPC\/#\/[A-Za-z0-9]{16}$/.test(String(url))) return replaceState.call(this, state, title);
    return replaceState.apply(this, arguments);
  };
  function local(url) {
    var resolved = new URL(String(url), location.href);
    if (resolved.origin === origin) {
      // The capture contains one fixture family for each API, shared across demo regions.
      var file = resolved.pathname.split('/').pop(), area = '';
      if (/^VSG2pkcWFaOHpkNlQ-\d+\.txt$/.test(file)) {
        resolved.pathname = '/ICBCCOIN/outer/iepa_area03/servlets/VSG2pkcWFaOHpkNlQ-2.txt';
        file = 'VSG2pkcWFaOHpkNlQ-2.txt';
      }
      if (file === 'qTi9BV2hDkYkdx0hlS') area = '03';
      if (/^nova1JzSGc4R3RwYn-\d+\.txt$/.test(file)) area = '19';
      if (/^(?:uUWZUZUFqeTk4cVBYy9-\d+\.txt|VSG2pkcWFaOHpkNlQ-2\.txt|vSUFiXIwT0xrNGNLRFB6Q\.txt)$/.test(file)) area = '03';
      if (/^jV4Umc2QXVFdDhkW(?:\.html)?$/.test(file)) area = '09';
      if (area) resolved.pathname = resolved.pathname.replace(/\/iepa_area\d+\//, '/iepa_area'+area+'/');
      return resolved.href;
    }
    // Captured bank resource links are resolved exclusively against bundled fixtures.
    if (/(^|\.)icbc\.com\.cn$/i.test(resolved.hostname) && /^\/ICBC(?:COIN|DynamicSite|\/)/.test(resolved.pathname)) return origin + resolved.pathname + resolved.search;
    throw new Error('模拟练习只使用App内置资源');
  }
  var originalFetch = window.fetch;
  if (originalFetch) window.fetch = function (input, options) {
    try { return originalFetch.call(this, typeof input === 'string' ? local(input) : new Request(local(input.url), input), options); }
    catch (error) { return Promise.reject(error); }
  };
  var open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    var args = Array.prototype.slice.call(arguments); args[1] = local(url); return open.apply(this, args);
  };
  if (navigator.sendBeacon) {
    var beacon = navigator.sendBeacon.bind(navigator);
    navigator.sendBeacon = function (url, data) { try { return beacon(local(url), data); } catch (_) { return false; } };
  }
  function badge() {
    if (!document.body || document.getElementById('lumian-mock-notice')) return;
    var el = document.createElement('div'); el.id = 'lumian-mock-notice';
    el.textContent = '内置模拟练习 · 不会产生真实预约';
    el.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:2147483645;background:#12345ce8;color:#fff;font:12px/1.6 sans-serif;padding:5px 10px;border-radius:8px;pointer-events:none';
    document.body.appendChild(el);
  }
  document.addEventListener('DOMContentLoaded', badge); setTimeout(badge, 500);
})();
