import UIKit

/// 应用内更新（iOS）：
/// 1. 启动请求 check_update.php，比对 CFBundleVersion（build 整数）；
/// 2. 有新版本弹窗（可选 / 强制）；
/// 3. App 内用 URLSession 下载 IPA（弹窗显示进度）；
/// 4. 下载完成弹系统分享面板 → 客户「存储到文件」或直接选自签工具导入签名。
final class UpdateClient {

    private static let checkApi = LicenseClient.base + "check_update.php"

    /// 强引用当前下载器，防止下载过程中被释放
    private static var activeDownloader: Downloader?

    typealias Ready = () -> Void

    /// 检查更新；除强制更新外最终回调 ready（继续授权检查）
    static func check(presenter: UIViewController, ready: @escaping Ready) {
        let build = Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0") ?? 0
        guard let url = URL(string: checkApi) else { ready(); return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 12
        req.httpMethod = "POST"
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: [
            "platform": "ios",
            "version_code": build,
            "key": LicenseClient.apiKey
        ])

        URLSession.shared.dataTask(with: req) { data, _, _ in
            guard let data = data,
                  let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  (obj["code"] as? Int ?? 1) == 0,
                  (obj["has_update"] as? Int ?? 0) == 1 else {
                DispatchQueue.main.async { ready() }
                return
            }
            DispatchQueue.main.async { showAlert(presenter, obj, ready) }
        }.resume()
    }

    // MARK: - 更新弹窗

    private static func showAlert(_ presenter: UIViewController, _ info: [String: Any], _ ready: @escaping Ready) {
        let force = (info["is_force"] as? Int ?? 0) == 1
        let ver = info["version_name"] as? String ?? ""
        let notes = info["update_notes"] as? String ?? ""
        let urlStr = info["download_url"] as? String ?? ""

        let alert = UIAlertController(
            title: "发现新版本 v\(ver)",
            message: notes.isEmpty ? "点击「立即下载」获取新版安装包。" : notes,
            preferredStyle: .alert)

        if !force {
            alert.addAction(UIAlertAction(title: "以后再说", style: .cancel) { _ in ready() })
        }
        alert.addAction(UIAlertAction(title: "立即下载", style: .default) { _ in
            if !force { ready() }   // 可选更新：下载不阻断使用
            startDownload(presenter, urlStr)
        })
        presenter.present(alert, animated: true)
    }

    // MARK: - 下载

    private static func startDownload(_ presenter: UIViewController, _ urlStr: String) {
        if activeDownloader != nil { return }
        let dl = Downloader(presenter: presenter)
        activeDownloader = dl
        dl.start(urlStr)
    }

    /// 下载器：delegate 跟踪进度，完成后移动文件并弹分享面板
    private final class Downloader: NSObject {
        weak var presenter: UIViewController?
        let progressAlert: UIAlertController
        let progressBar = UIProgressView(progressViewStyle: .default)
        let percentLabel = UILabel()
        var session: URLSession!
        var fileName = "lumian-update.ipa"

        init(presenter: UIViewController) {
            self.presenter = presenter
            progressAlert = UIAlertController(title: "正在下载新版…", message: "\n\n", preferredStyle: .alert)
            super.init()

            progressBar.frame = CGRect(x: 18, y: 52, width: 234, height: 8)
            progressBar.progress = 0
            percentLabel.frame = CGRect(x: 18, y: 62, width: 234, height: 22)
            percentLabel.textAlignment = .center
            percentLabel.font = .systemFont(ofSize: 13)
            percentLabel.text = "0%"
            progressAlert.view.addSubview(progressBar)
            progressAlert.view.addSubview(percentLabel)

            session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        }

        func start(_ urlStr: String) {
            guard let url = URL(string: urlStr) else { fail("下载地址无效"); return }
            if let n = url.lastPathComponent.removingPercentEncoding, !n.isEmpty {
                fileName = n
            }
            if !fileName.lowercased().hasSuffix(".ipa") { fileName += ".ipa" }
            presenter?.present(progressAlert, animated: true)
            session.downloadTask(with: url).resume()
        }

        func share(_ file: URL) {
            let vc = UIActivityViewController(activityItems: [file], applicationActivities: nil)
            vc.popoverPresentationController?.sourceView = presenter?.view
            presenter?.present(vc, animated: true) {
                activeDownloader = nil
            }
        }

        func fail(_ msg: String) {
            let done = {
                let a = UIAlertController(title: "下载失败", message: msg, preferredStyle: .alert)
                a.addAction(UIAlertAction(title: "好", style: .default) { _ in activeDownloader = nil })
                self.presenter?.present(a, animated: true)
            }
            if progressAlert.presentingViewController != nil {
                progressAlert.dismiss(animated: true, completion: done)
            } else {
                done()
            }
        }
    }
}

// MARK: - URLSessionDownloadDelegate

extension UpdateClient.Downloader: URLSessionDownloadDelegate {

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        DispatchQueue.main.async {
            if totalBytesExpectedToWrite > 0 {
                let p = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
                self.progressBar.setProgress(p, animated: true)
                self.percentLabel.text = "\(Int(p * 100))%"
            } else {
                self.percentLabel.text = String(format: "%.1f MB", Double(totalBytesWritten) / 1048576.0)
            }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        let dest = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
        do {
            try? FileManager.default.removeItem(at: dest)
            try FileManager.default.moveItem(at: location, to: dest)
        } catch {
            DispatchQueue.main.async { self.fail("文件保存失败：" + error.localizedDescription) }
            return
        }
        DispatchQueue.main.async {
            self.progressAlert.dismiss(animated: true) {
                self.share(dest)
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error else { return }
        let nsErr = error as NSError
        if nsErr.domain == NSURLErrorDomain && nsErr.code == NSURLErrorCancelled { return }
        DispatchQueue.main.async { self.fail(error.localizedDescription) }
    }
}
