import UIKit

/// Pro 版服务器客户端：卡密激活 / 续验 / 身份信息云端保存 / 云端 OCR。
/// 全部走 URLSession（系统原生，无第三方依赖），回调统一回到主线程。
final class LicenseClient {

    /// 服务器地址（以后申请了 HTTPS 把 http 改成 https 即可）
    static let base = "http://121.40.81.223/api/"
    /// 与服务器 config.php 的 API_KEY 保持一致
    static let apiKey = "Lm2026Secret888"

    typealias Callback = (Bool, String, [String: Any]?) -> Void

    /// 设备唯一标识（卸载重装会变；与安卓 ANDROID_ID 语义一致）
    static var deviceId: String {
        UIDevice.current.identifierForVendor?.uuidString ?? "unknown-ios"
    }

    /// 版本号整数（应用内更新比对 + 续验上报口径一致：取 CFBundleVersion build）
    static func versionCode() -> Int {
        Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0") ?? 0
    }

    /// 激活：POST activate.php {card_key, device_id, key} → 成功返回 token + access
    static func activate(cardKey: String, cb: @escaping Callback) {
        post("activate.php", [
            "card_key": cardKey.trimmingCharacters(in: .whitespacesAndNewlines),
            "device_id": deviceId,
            "key": apiKey
        ], cb)
    }

    /// 续验（门禁内部调用）：POST verify.php
    /// body = {token, device_id, key, platform:"ios", version_code, integ:{路径:sha256}, sig:""}
    /// 注意：按移动端前向兼容约定，不发 files 字段；sig 留空（iOS 签名由系统管控）。
    /// 成功(code:0 且带 access)→落盘 access 并回调 (true, access)；
    /// code:1（服务端明确拒绝）→ 清许可回调 (false, "")；
    /// code:-1 网络异常 → 不清许可，回调 (false, "")，交给本地宽限。
    static func renewVerify(cb: @escaping (Bool, String) -> Void) {
        let integ = LicenseGate.computeInteg()
        let body: [String: Any] = [
            "token": LicenseStore.token(),
            "device_id": deviceId,
            "key": apiKey,
            "platform": "ios",
            "version_code": versionCode(),
            "integ": integ,
            "sig": ""
        ]
        post("verify.php", body) { _, _, data in
            guard let obj = data, let code = obj["code"] as? Int else {
                cb(false, ""); return            // 传输失败 → 网络异常，不清
            }
            if code == 0, let access = obj["access"] as? String, !access.isEmpty {
                LicenseStore.setAccess(access, expires: obj["expires_at"] as? String)
                cb(true, access)
            } else if code == 1 {
                LicenseStore.clear()             // 服务端明确拒绝 → 清许可
                cb(false, "")
            } else {
                cb(false, "")                    // 其他：不清
            }
        }
    }

    /// 身份信息云端保存：POST save_info.php（静默，失败不打断用户）
    static func saveInfo(personsJson: String, cb: @escaping Callback) {
        post("save_info.php", [
            "token": LicenseStore.token(),
            "device_id": deviceId,
            "key": apiKey,
            "persons": toServerPersons(personsJson)
        ], cb)
    }

    /// 云端 OCR：POST ocr.php（先过门禁再带 token/device 调，付费能力服务端同样校验授权）
    static func cloudOcr(imageBase64: String, cb: @escaping Callback) {
        post("ocr.php", [
            "image_base64": imageBase64,
            "key": apiKey,
            "token": LicenseStore.token(),
            "device_id": deviceId
        ], cb)
    }

    /// 字段映射：App 本地字段 → 服务器字段（与安卓一致）
    /// idcard→id_card，exchangeTime→ex_date；bank/address 本地没有，留空
    private static func toServerPersons(_ json: String) -> [[String: String]] {
        guard let data = json.data(using: .utf8),
              let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: String]] else {
            return []
        }
        return arr.map { p in
            var o: [String: String] = [:]
            o["name"] = p["name"] ?? ""
            o["remark"] = p["remark"] ?? ""
            o["phone"] = p["phone"] ?? ""
            o["id_card"] = p["idcard"] ?? ""
            o["province"] = p["province"] ?? ""
            o["city"] = p["city"] ?? ""
            o["district"] = p["district"] ?? ""
            o["bank"] = ""
            o["branch"] = p["branch"] ?? ""
            o["address"] = ""
            o["ex_date"] = p["exchangeTime"] ?? ""
            o["quantity"] = p["quantity"] ?? ""
            return o
        }
    }

    /// 人员信息按身份证号预检（全端生效）：成功时 data 含 blocked 字典
    /// 失败自动静默重试一次，降低偶发网络抖动导致的漏拦
    static func checkPerson(idCard: String, cb: @escaping Callback) {
        let body: [String: Any] = ["key": apiKey, "id_card": idCard]
        post("check_person.php", body) { ok, msg, data in
            if ok { cb(true, msg, data); return }
            post("check_person.php", body) { ok2, msg2, data2 in
                cb(ok2, ok2 ? msg2 : msg, data2)
            }
        }
    }

    private static func post(_ api: String, _ body: [String: Any], _ cb: @escaping Callback) {
        guard let url = URL(string: base + api) else {
            DispatchQueue.main.async { cb(false, "地址错误", nil) }
            return
        }
        var req = URLRequest(url: url)
        req.timeoutInterval = 15
        req.httpMethod = "POST"
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: req) { data, _, err in
            guard let data = data, err == nil else {
                DispatchQueue.main.async { cb(false, "网络请求失败：" + (err?.localizedDescription ?? "未知"), nil) }
                return
            }
            guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                DispatchQueue.main.async { cb(false, "服务器返回异常", nil) }
                return
            }
            let code = obj["code"] as? Int ?? 1
            let msg = obj["msg"] as? String ?? ""
            DispatchQueue.main.async { cb(code == 0, msg, obj) }
        }.resume()
    }
}
