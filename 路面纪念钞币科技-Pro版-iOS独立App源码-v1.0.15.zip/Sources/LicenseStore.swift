import UIKit

/// Pro 版授权信息存取（与电脑端 storage.local 对齐：token / access / card_type / expires_at）
enum LicenseStore {

    private static let kToken = "sx_license_token"
    private static let kAccess = "sx_license_access"
    private static let kType = "sx_license_type"
    private static let kExpires = "sx_license_expires"

    static func token() -> String {
        UserDefaults.standard.string(forKey: kToken) ?? ""
    }

    /// 服务器 ECDSA 签发的访问票据（b64url(payload).b64url(sig)）
    static func access() -> String {
        UserDefaults.standard.string(forKey: kAccess) ?? ""
    }

    static func cardType() -> String {
        UserDefaults.standard.string(forKey: kType) ?? ""
    }

    static func expiresAt() -> String {
        UserDefaults.standard.string(forKey: kExpires) ?? ""
    }

    /// 激活成功：保存 token 与 access（access 为空串时也先落盘空值）
    static func setActivated(token: String, access: String, type: String, expires: String?) {
        UserDefaults.standard.set(token, forKey: kToken)
        UserDefaults.standard.set(access, forKey: kAccess)
        UserDefaults.standard.set(type, forKey: kType)
        UserDefaults.standard.set(expires ?? "", forKey: kExpires)
    }

    /// 续验成功：仅刷新 access（不动 token/卡类型）
    static func setAccess(_ access: String, expires: String?) {
        UserDefaults.standard.set(access, forKey: kAccess)
        if let e = expires { UserDefaults.standard.set(e, forKey: kExpires) }
    }

    /// 服务器明确拒绝（code:1）时清许可；网络异常不得调用此方法
    static func clear() {
        UserDefaults.standard.removeObject(forKey: kToken)
        UserDefaults.standard.removeObject(forKey: kAccess)
        UserDefaults.standard.removeObject(forKey: kType)
        UserDefaults.standard.removeObject(forKey: kExpires)
    }
}
