"""Run before XcodeGen/build; keep the bundled integrity map in sync with actual JS bytes."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
web=root/'Sources/WebAssets/web'
files=['content.js','bridge_ios.js','banks/BankMatch.js','banks/sx_common.js','banks/sx_branch_finder.js',
       'banks/sx_abc.js','banks/sx_boc.js','banks/sx_ccb.js','banks/sx_psbc.js','banks/sx_icbc.js','page_guard.js','style_patch.js','mobile_touch_patch.js','banks/date_fill.js','banks/test_bridge.js']
manifest={name:hashlib.sha256((web/name).read_bytes()).hexdigest() for name in files}
(web/'integrity_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Generated integrity manifest:',len(manifest),'files')
