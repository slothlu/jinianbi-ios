#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodegen >/dev/null || { echo "Install XcodeGen first: brew install xcodegen"; exit 1; }
command -v xcodebuild >/dev/null || { echo "Xcode is required on macOS"; exit 1; }
python3 _tools/generate_integrity.py
xcodegen generate
mkdir -p build
xcodebuild -project LuMianJiNianBi.xcodeproj -scheme LuMianJiNianBi \
    -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
    -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY="" build 2>&1 | tee build/build.log
APP="build/DerivedData/Build/Products/Release-iphoneos/LuMianJiNianBi.app"
test -d "$APP"
VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Info.plist")
PACKAGE_DIR=$(mktemp -d "$(pwd)/build/ipa-stage.XXXXXX")
mkdir -p "$PACKAGE_DIR/Payload"
ditto "$APP" "$PACKAGE_DIR/Payload/LuMianJiNianBi.app"
ditto -c -k --keepParent "$PACKAGE_DIR/Payload" "build/LuMianJiNianBi-v${VERSION}-unsigned.ipa"
echo "Created build/LuMianJiNianBi-v${VERSION}-unsigned.ipa (requires signing before installation)"
