import Foundation

enum AppOptions {
    static let keys = ["autoOcr", "autoSubmit", "pageLocked"]
    static func enabled(_ key: String) -> Bool {
        (UserDefaults.standard.object(forKey: "sx_option_" + key) as? Bool) ?? true
    }
    static func set(_ key: String, _ enabled: Bool) { UserDefaults.standard.set(enabled, forKey: "sx_option_" + key) }
    static func json() -> String {
        let values = Dictionary(uniqueKeysWithValues: keys.map { ($0, enabled($0)) })
        guard let data = try? JSONSerialization.data(withJSONObject: values), let json = String(data: data, encoding: .utf8) else { return "{}" }
        return json
    }
}
