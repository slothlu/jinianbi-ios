/* Page zoom lock: preserve page width and scroll; restore original viewport and fonts on unlock. */
(function () {
  if (window.__SX_PAGE_GUARD__) return;
  window.__SX_PAGE_GUARD__ = true;
  var locked = false, observer = null, viewport = null;
  var created = new Set(), enforced = new Map(), scales = new Map();
  var originals = new Map(), fontOriginals = new Map();
  function isEditable(el) { return el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)); }
  function protect() {
    if (!locked || !document.documentElement) return;
    var metas = document.querySelectorAll('meta[name="viewport"]');
    viewport = metas.length ? metas[0] : viewport;
    if (!viewport || !viewport.isConnected) {
      viewport = document.createElement('meta'); viewport.name = 'viewport'; created.add(viewport);
      (document.head || document.documentElement).appendChild(viewport);
    }
    var nodes = metas.length ? Array.prototype.slice.call(metas) : [viewport];
    nodes.forEach(function (meta) {
      if (!originals.has(meta) || enforced.has(meta) && meta.getAttribute('content') !== enforced.get(meta)) {
        originals.set(meta, meta.getAttribute('content')); scales.delete(meta);
      }
      var before = originals.get(meta) || '';
      // Keep existing width/initial-scale. Do not force desktop bank forms into a narrow viewport.
      var scale = (before.match(/(?:^|,)\s*initial-scale\s*=\s*([\d.]+)/i) || [])[1];
      var currentScale = window.visualViewport && window.visualViewport.scale;
      scale = scales.get(meta) || (Number.isFinite(currentScale) && currentScale > 0 ? currentScale : Number(scale) || 1);
      scales.set(meta, scale);
      var content = before.split(',').filter(function (s) { return !/^\s*(?:user-scalable|minimum-scale|maximum-scale)\s*=/i.test(s); }).filter(Boolean).join(',');
      content += (content ? ',' : '') + 'minimum-scale=' + scale + ',maximum-scale=' + scale + ',user-scalable=no';
      if (meta.getAttribute('content') !== content) meta.setAttribute('content', content);
      enforced.set(meta, content);
    });
    document.querySelectorAll('input,textarea,select').forEach(function (el) {
      var size = parseFloat(window.getComputedStyle(el).fontSize);
      if (size < 16 && !fontOriginals.has(el)) {
        fontOriginals.set(el, [el.style.getPropertyValue('font-size'), el.style.getPropertyPriority('font-size')]);
        el.style.setProperty('font-size', '16px', 'important');
      }
    });
  }
  window.__SX_SET_PAGE_LOCK__ = function (enabled) {
    locked = enabled === true;
    if (observer) { observer.disconnect(); observer = null; }
    if (locked) {
      protect();
      if (document.documentElement) {
        observer = new MutationObserver(function () { protect(); });
        observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['content'] });
      }
    } else {
      originals.forEach(function (value, meta) { if (meta.getAttribute('content') !== enforced.get(meta)) return; if (value === null) meta.removeAttribute('content'); else meta.setAttribute('content', value); });
      originals.clear(); enforced.clear(); scales.clear();
      created.forEach(function (meta) { meta.remove(); }); created.clear(); viewport = null;
      fontOriginals.forEach(function (value, el) { if (el.style.getPropertyValue('font-size') !== '16px' || el.style.getPropertyPriority('font-size') !== 'important') return; if (value[0]) el.style.setProperty('font-size', value[0], value[1]); else el.style.removeProperty('font-size'); });
      fontOriginals.clear();
    }
    window.__SX_PAGE_LOCKED__ = locked;
  };
  document.addEventListener('touchstart', function (e) { if (locked && e.touches && e.touches.length > 1 && e.cancelable) e.preventDefault(); }, { passive: false });
  document.addEventListener('gesturestart', function (e) { if (locked && e.cancelable) e.preventDefault(); }, { passive: false });
  document.addEventListener('dblclick', function (e) { if (locked && !isEditable(e.target) && e.cancelable) e.preventDefault(); }, { passive: false });
  document.addEventListener('DOMContentLoaded', function () { if (locked) window.__SX_SET_PAGE_LOCK__(true); });
})();
