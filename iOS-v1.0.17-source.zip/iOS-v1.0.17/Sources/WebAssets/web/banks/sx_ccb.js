/**
 * 路面纪念钞币科技 · 中国建设银行（CCB）适配器
 * element-ui 增强型：
 *   ① 基础字段 + 证件类型 + 原生省市区 select
 *   ② 省 / 市 / 区 / 网点 四个独立 el-select 依次选择（匹配不到退回第一个可见项）
 *   ③ 兑换日期、数量、协议勾选
 *   ④ 提交按钮文案兜底含“下一步”
 */
(function () {
  "use strict";
  const C = window.__SX_COMMON__;

  const adapter = {
    id: "CCB",
    detect: () => {
      const host = location.hostname || "";
      const path = location.pathname || "";
      return host.includes("ccb") || host.includes("ccbank") || path.includes("建设银行") || path.includes("ccb");
    },

    async waitForOpen() { },

    getSelectorMap: () => ({
      fullName:
        'input[name*="userName"],input[id*="userName"],input[name*="name"],input[id*="name"],input[placeholder*="客户姓名"],input[placeholder*="姓名"]',
      idType: 'select[name*="certType"],select[id*="certType"],select[name*="idType"],select[id*="idType"]',
      idNumber:
        'input[name*="certNo"],input[id*="certNo"],input[name*="idNo"],input[id*="idNo"],input[name*="idNumber"],input[id*="idNumber"],input[placeholder*="证件号"],input[placeholder*="证件号码"]',
      mobile:
        'input[name*="phone"],input[id*="phone"],input[name*="mobile"],input[id*="mobile"],input[placeholder*="手机号码"],input[placeholder*="手机号"]',
      address:
        'textarea[name*="address"],textarea[id*="address"],input[name*="address"],input[id*="address"],input[placeholder*="联系地址"],textarea[placeholder*="联系地址"]',
      province: 'select[name*="province"],select[id*="province"]',
      city: 'select[name*="city"],select[id*="city"]',
      district: 'select[name*="district"],select[id*="district"],select[name*="county"],select[id*="county"]',
      branch: 'input[name*="branch"],input[id*="branch"],input[placeholder*="网点"],.el-cascader input.el-input__inner',
      submitButton: 'button[type="submit"],input[type="submit"],.el-button--primary'
    }),

    findInputByKeywords(key) {
      const kw = {
        fullName: ["姓名", "客户姓名", "兑换人"],
        idNumber: ["证件号码", "证件号", "身份证"],
        mobile: ["手机号", "手机号码", "联系电话"],
        address: ["联系地址", "详细地址", "通讯地址"],
        branch: ["网点", "兑换网点", "选择网点"]
      };
      const words = kw[key];
      if (!words) return null;
      for (const el of document.querySelectorAll("input, textarea")) {
        if (!C.isVisible(el) || el.readOnly) continue;
        const hay = C.esc(
          (el.getAttribute("placeholder") || "") + "|" + (el.getAttribute("aria-label") || "") + "|" +
          (el.name || "") + "|" + (el.id || "") + "|" + (el.closest("label") ? C.esc(el.closest("label").textContent) : "")
        );
        if (words.some((w) => hay.indexOf(C.esc(w)) >= 0)) return el;
      }
      return null;
    },

    // 省 / 市 / 区 / 网点 四个独立 el-select 依次选择
    async fillCCBBranchSelectors(person) {
      const BF = window.__branchFinder__;
      if (!BF) return { success: false, message: "网点引擎未加载" };
      const steps = [
        { value: person.province, kind: "province", keywords: ["省/直辖市", "请选择省份", "请选择省", "省份"] },
        { value: person.city, kind: "city", keywords: ["市", "请选择城市", "请选择市", "城市"] },
        { value: person.district, kind: "district", keywords: ["区/县", "请选择区县", "请选择区域", "区县", "区域"] },
        { value: person.branch, kind: "branch", keywords: ["请选择网点", "选择兑换网点", "兑换网点", "预约网点"] }
      ];
      const done = [];
      for (const st of steps) {
        if (!st.value) continue;
        const r = await BF.selectElSelectValue(st.keywords, st.value, st.kind, true);
        if (r.skipped) continue;
        if (!r.success) {
          console.warn("[CCB]", st.kind, "选择失败:", r.message);
          if (st.kind === "branch") return { success: false, failedStep: st.kind, message: r.message, done };
        } else {
          console.log("[CCB]", st.kind, "选择成功:", r.text);
          done.push(st.kind);
        }
      }
      return { success: true, done };
    },

    async fillForm(person = {}) {
      person = C.normalizePerson(person);
      const selMap = this.getSelectorMap();
      const smart = window.__SX_SMART_FIND__;
      const set = (key, val) => {
        if (val == null || val === "") return;
        let el = smart ? smart(key) : null;
        if (!el && key === "quantity") el = C.findQuantityInput();
        if (!el && selMap[key]) el = C.safeQ(selMap[key]);
        if (!el && this.findInputByKeywords) el = this.findInputByKeywords(key);
        if (el) C.fillValue(el, val);
        else console.warn("[CCB] 未找到", key);
      };

      set("fullName", person.fullName);
      set("idNumber", person.idNumber);
      set("mobile", person.mobile);
      set("address", C.fullAddress(person));

      const idType = (smart && smart("idType")) || C.safeQ(selMap.idType);
      if (idType) C.selectIdType(idType);

      // 原生省/市/区 select（若存在）
      C.fillRegionSelects(person, selMap);

      // 省/市/区/网点 四个独立 el-select
      const r = await this.fillCCBBranchSelectors(person);
      if (!r.success) {
        console.warn("[CCB] 分段下拉失败，尝试 BranchFinder 完整路径:", r.message);
        const parts = C.resolveBranchParts(person);
        if (parts.length && window.__branchFinder__) {
          try {
            const rr = await window.__branchFinder__.autoFillBranch(parts, { enableLog: false });
            console.log("[CCB] BranchFinder 兜底结果:", rr);
          } catch (e) { console.warn("[CCB] BranchFinder 报错:", e); }
        }
      }

      const date = C.normalizeExchangeDate(person.exchangeTime);
      const dateEl = C.findExchangeDateInput();
      if (date && dateEl) {
        C.fillValue(dateEl, date);
        console.log("[CCB] 兑换日期填写成功:", date);
      } else if (person.exchangeTime) {
        console.warn("[CCB] 未找到兑换日期输入框");
      }

      set("quantity", person.quantity);
      C.autoCheckAgreementCheckboxes();
      console.log("[CCB] 表单填写完成");
      return { ok: true, bank: "CCB" };
    },

    async submit() {
      const btn = C.safeQ('button[type="submit"], input[type="submit"], .el-button--primary, .submit, .btn-submit');
      if (btn && !btn.disabled) {
        btn.click();
        console.log("[CCB] 提交按钮已点击");
        return true;
      }
      const words = ["提交", "确认", "下一步", "预约", "完成"];
      const fallback = C.findButtonByText(words);
      if (fallback && !fallback.disabled) {
        fallback.click();
        console.log("[CCB] 提交按钮（文案匹配）已点击");
        return true;
      }
      console.warn("[CCB] 未找到提交按钮");
      return false;
    },

    async verifyResult() {
      const text = (document.body.innerText || document.body.textContent || "").toLowerCase();
      return /成功|已受理|完成|预约成功|提交成功|操作成功/.test(text);
    }
  };

  window.shuixian.register(adapter);
})();
