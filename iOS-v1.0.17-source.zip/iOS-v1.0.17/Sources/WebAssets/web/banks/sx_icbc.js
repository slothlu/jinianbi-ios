/**
 * 路面纪念钞币科技 · 中国工商银行（ICBC）适配器
 * element-ui 增强型：
 *   ① 基础字段（地址缺省用省市区拼接）+ 证件类型
 *   ② 数量 → 兑换日期
 *   ③ 省 / 市 / 区 / 网点 独立 el-select（全局 placeholder 匹配，匹配不到不退回）
 *   ④ 三级回退：分段 el-select → BranchFinder 省/市/网点 → 网点输入框直写
 *   ⑤ 协议勾选；提交文案兜底含“下一步”
 */
(function () {
  "use strict";
  const C = window.__SX_COMMON__;

  const adapter = {
    id: "ICBC",
    detect: () => (location.hostname || "").includes("icbc"),

    async waitForOpen() { },

    getSelectorMap: () => ({
      fullName: "#custName, input[name=\"custName\"]",
      idType: "#idType, select[name=\"idType\"]",
      idNumber: "#idNo, input[name=\"idNo\"]",
      mobile: "#mobile, input[name=\"mobile\"]",
      address: "#address, textarea[name=\"address\"]",
      zipCode: "#zip, input[name=\"zip\"]",
      province: "select#province",
      city: "select#city",
      district: "select#district",
      submitButton: "button#submit, button.btn-submit, .submit"
    }),

    findInputByKeywords(key) {
      const kw = {
        fullName: ["姓名", "客户姓名", "兑换人"],
        idNumber: ["证件号码", "证件号", "身份证"],
        mobile: ["手机号", "手机号码", "联系电话"],
        address: ["联系地址", "详细地址", "通讯地址"],
        branch: ["网点", "兑换网点", "选择网点"]
      };
      const words = kw[key];
      if (!words) return null;
      for (const el of document.querySelectorAll("input, textarea")) {
        if (!C.isVisible(el) || el.readOnly) continue;
        const hay = C.esc(
          (el.getAttribute("placeholder") || "") + "|" + (el.getAttribute("aria-label") || "") + "|" +
          (el.name || "") + "|" + (el.id || "") + "|" + (el.closest("label") ? C.esc(el.closest("label").textContent) : "")
        );
        if (words.some((w) => hay.indexOf(C.esc(w)) >= 0)) return el;
      }
      return null;
    },

    // 数量输入框：placeholder/name/id 关键词 + number/max 兜底
    findQuantityInput() {
      return C.findQuantityInput();
    },

    // 省 / 市 / 区 / 网点 独立 el-select（全局 placeholder 匹配，不退回第一个）
    async fillICBCBranchSelectors(person) {
      const BF = window.__branchFinder__;
      if (!BF) return { success: false, message: "网点引擎未加载" };
      const steps = [
        { value: person.province, keywords: ["请选择省份", "省份"] },
        { value: person.city, keywords: ["请选择城市", "城市"] },
        { value: person.district, keywords: ["请选择区县", "区县", "请选择区域"] },
        { value: person.branch, keywords: ["请选择网点", "选择预约网点", "兑换网点"] }
      ];
      for (const st of steps) {
        if (!st.value) continue;
        const r = await BF.selectElSelectValue(st.keywords, st.value, null, false);
        if (r.skipped) continue;
        if (!r.success) return { success: false, failedStep: st.value, message: r.message };
        console.log("[ICBC] 选择成功:", st.value, "→", r.text);
      }
      return { success: true };
    },

    async fillForm(person = {}) {
      person = C.normalizePerson(person);
      const selMap = this.getSelectorMap();
      const smart = window.__SX_SMART_FIND__;
      const set = (key, val) => {
        if (val == null || val === "") return;
        let el = smart ? smart(key) : null;
        if (!el && key === "quantity") el = C.findQuantityInput();
        if (!el && selMap[key]) el = C.safeQ(selMap[key]);
        if (!el && this.findInputByKeywords) el = this.findInputByKeywords(key);
        if (el) C.fillValue(el, val);
        else console.warn("[ICBC] 未找到", key);
      };

      set("fullName", person.fullName);
      set("idNumber", person.idNumber);
      set("mobile", person.mobile);
      set("address", C.fullAddress(person));
      const idType = (smart && smart("idType")) || C.safeQ(selMap.idType);
      if (idType) C.selectIdType(idType);

      // 原生省/市/区 select（若存在）
      C.fillRegionSelects(person, selMap);

      // 数量（在日期之前）
      if (person.quantity) {
        const q = this.findQuantityInput();
        if (q) { C.fillValue(q, person.quantity); console.log("[ICBC] 预约数量填写成功:", person.quantity); }
        else console.warn("[ICBC] 未找到数量输入框");
      }

      // 兑换日期
      const date = C.normalizeExchangeDate(person.exchangeTime);
      const dateEl = C.findExchangeDateInput();
      if (date && dateEl) {
        C.fillValue(dateEl, date);
        console.log("[ICBC] 兑换日期填写成功:", date);
      } else if (person.exchangeTime) {
        console.warn("[ICBC] 未找到兑换日期输入框");
      }

      // 网点三级回退
      const r = await this.fillICBCBranchSelectors(person);
      if (!r.success) {
        console.warn("[ICBC] 分段下拉失败:", r.failedStep, r.message);
        const BF = window.__branchFinder__;
        const fallbackParts = person.branchPath ? C.resolveBranchParts(person) : [person.province, person.city, person.branch].filter(Boolean);
        let rr = null;
        if (BF && fallbackParts.length) {
          try { rr = await BF.autoFillBranch(fallbackParts, { enableLog: false }); } catch (e) { rr = null; }
        }
        if (!rr || !rr.success) {
          // 三级回退：网点输入框直写
          const input = BF ? BF.findBranchInputFallback() : null;
          if (input && fallbackParts.length) {
            const direct = fallbackParts.join("/");
            C.fillValue(input, direct);
            console.log("[ICBC] 三级回退直写网点:", direct);
          } else {
            console.warn("[ICBC] 网点选择全部失败");
          }
        }
      }

      C.autoCheckAgreementCheckboxes();
      console.log("[ICBC] 表单填写完成");
      return { ok: true, bank: "ICBC" };
    },

    async submit() {
      const btn = C.safeQ('button#submit, button.btn-submit, .submit, button[type="submit"], .el-button--primary');
      if (btn && !btn.disabled) {
        btn.click();
        console.log("[ICBC] 提交按钮已点击");
        return true;
      }
      // 文案兜底：遍历 button / .el-button / .btn / [role=button]
      const words = ["提交", "确认", "下一步", "预约"];
      const candidates = document.querySelectorAll("button, .el-button, .btn, [role='button'], input[type='submit']");
      for (const b of candidates) {
        if (!C.isVisible(b) || b.disabled) continue;
        const t = C.esc(b.textContent || "") + "|" + C.esc(b.value || "");
        if (words.some((w) => t.indexOf(C.esc(w)) >= 0)) {
          b.click();
          console.log("[ICBC] 提交按钮（文案匹配）已点击");
          return true;
        }
      }
      console.warn("[ICBC] 未找到提交按钮");
      return false;
    },

    async verifyResult() {
      const text = (document.body.innerText || document.body.textContent || "").toLowerCase();
      return /成功|已受理|完成|预约成功|提交成功|操作成功/.test(text);
    }
  };

  window.shuixian.register(adapter);
})();
