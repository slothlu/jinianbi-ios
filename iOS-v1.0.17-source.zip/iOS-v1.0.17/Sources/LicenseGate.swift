import Foundation
import CryptoKit

/// 授权门禁（与电脑端 background.js 行为对齐）：
///
/// 原理：功能执行必须持有服务器用 ECDSA P-256 私钥签发的访问票据(access)；
/// App 只内置公钥，能验真伪但无法伪造。票据绑定设备号、约 6 小时有效。
///
/// access 格式（与电脑端 / 安卓 / Node 对照验证完全一致）：
///   b64url(payloadJSON).b64url(rawSignature64)
///   - payloadJSON = {"d":设备号, "c":卡类型, "iat":签发秒, "exp":到期秒}
///   - rawSignature64 = ECDSA SHA-256 的 raw(r||s)，r、s 各 32 字节共 64 字节
///
/// gateEnsure 语义（同电脑端）：
///   本地票有效且剩余 > 5 分钟 → 直接放行（不联网）；
///   否则联网 verify 续验（上报 Bundle 网页资源 SHA-256 完整性）→ 成功放行；
///   续验失败但本地票仍未过期 → 断网宽限放行；
///   无任何有效票 → fail-closed。
enum LicenseGate {

    /// 客户界面统一中性话术（锁定/失败不外泄任何技术细节）
    static let neutralFailure = "当前预约人数较多，请稍后再试"

    // MARK: - 验签公钥（P-256 JWK，对应服务器私钥；可公开，只能验签）
    private static let jwkX = "Fbn3dchcaVnjNQ431HFqctfZax5Cc5377pYQTDUSpkI"
    private static let jwkY = "KOn6q_p3X_XD3-GkpsJuO51MIIA6hup1CA3yGy71abw"

    /// 本地放行阈值：剩余有效期需大于 5 分钟，否则联网续验（同电脑端）
    private static let localGraceSeconds: Double = 5 * 60

    /// 受完整性监控的 Bundle 网页资源：
    /// - path：逻辑路径（上报服务器 integrity 的 key，与电脑端口径一致，不含 web/ 前缀）
    /// - file：Bundle 内文件名（assetIndex 按 basename 查找）
    static let guardedAssets: [(path: String, file: String)] = [
        ("content.js",             "content.js"),
        ("bridge_ios.js",          "bridge_ios.js"),
        ("banks/BankMatch.js",     "BankMatch.js"),
        ("banks/sx_common.js",     "sx_common.js"),
        ("banks/sx_branch_finder.js", "sx_branch_finder.js"),
        ("banks/sx_abc.js",       "sx_abc.js"),
        ("banks/sx_boc.js",        "sx_boc.js"),
        ("banks/sx_ccb.js",        "sx_ccb.js"),
        ("banks/sx_psbc.js",       "sx_psbc.js"),
        ("banks/sx_icbc.js",       "sx_icbc.js"),
        ("page_guard.js", "page_guard.js"),
        ("style_patch.js", "style_patch.js"),
        ("mobile_touch_patch.js", "mobile_touch_patch.js"),
        ("banks/date_fill.js", "date_fill.js"),
        ("banks/test_bridge.js", "test_bridge.js")
    ]

    // MARK: - base64url（URL 安全、无填充）

    static func base64urlDecode(_ s: String) -> Data? {
        var v = s.replacingOccurrences(of: "-", with: "+")
                 .replacingOccurrences(of: "_", with: "/")
        while v.count % 4 != 0 { v += "=" }
        return Data(base64Encoded: v, options: [])
    }

    // MARK: - P-256 公钥（JWK x,y → CryptoKit）

    private static var cachedKey: P256.Signing.PublicKey?
    static func verifyKey() -> P256.Signing.PublicKey? {
        if let k = cachedKey { return k }
        guard let x = base64urlDecode(jwkX), let y = base64urlDecode(jwkY),
              x.count == 32, y.count == 32 else { return nil }
        // 首选未压缩点 0x04 || X(32) || Y(32)（65 字节，ANSI x9.62）
        let uncompressed = Data([0x04]) + x + y
        if let k = try? P256.Signing.PublicKey(rawRepresentation: uncompressed) {
            cachedKey = k; return k
        }
        // 兜底：压缩点 0x02/0x03 || X(32)（33 字节，奇偶由 y 最低位决定）
        let prefix: UInt8 = (y[y.count - 1] & 1) == 1 ? 0x03 : 0x02
        let compressed = Data([prefix]) + x
        cachedKey = try? P256.Signing.PublicKey(rawRepresentation: compressed)
        return cachedKey
    }

    // MARK: - 访问票据本地校验（验签 + 设备 + 到期）

    struct InspectResult {
        var ok: Bool
        var expired: Bool
        var payload: [String: Any]?
    }

    /// 本地验票：签名合法 + 设备号匹配 + 未过期。对应电脑端 inspectAccess。
    static func inspect(access: String) -> InspectResult {
        func bad(_ expired: Bool = false, _ payload: [String: Any]? = nil) -> InspectResult {
            InspectResult(ok: false, expired: expired, payload: payload)
        }
        guard !access.isEmpty, access.contains(".") else { return bad() }
        let parts = access.components(separatedBy: ".")
        guard parts.count == 2 else { return bad() }
        guard let key = verifyKey() else { return bad() }
        // payload 原文（b64url 解码后的 JSON 字节）
        guard let payloadData = base64urlDecode(parts[0]) else { return bad() }
        // 签名：raw r||s 必须正好 64 字节
        guard let sigData = base64urlDecode(parts[1]), sigData.count == 64 else { return bad() }
        guard let sig = try? P256.Signing.ECDSASignature(rawRepresentation: sigData) else { return bad() }
        // ECDSA SHA-256：先对 payloadData 求 SHA-256 摘要，再验
        let digest = SHA256.hash(data: payloadData)
        guard key.isValidSignature(sig, for: digest) else { return bad() }
        // 解析 payload
        guard let payload = (try? JSONSerialization.jsonObject(with: payloadData)) as? [String: Any] else { return bad() }
        // 设备绑定：d 必须等于本机 identifierForVendor
        let d = (payload["d"] as? String) ?? ""
        if d != LicenseClient.deviceId { return bad() }
        // 到期（exp 为秒）：exp <= now 视为过期
        let exp = (payload["exp"] as? Double) ?? 0
        let now = Date().timeIntervalSince1970
        if exp <= now { return bad(true, payload) }
        return InspectResult(ok: true, expired: false, payload: payload)
    }

    // MARK: - 完整性：Bundle 资源 SHA-256

    /// 建立 文件名 → Bundle 内绝对路径 索引（与 ViewController.assetIndex 同法）
    private static var bundleIndex: [String: String]?
    static func bundledPath(basename: String) -> String? {
        if bundleIndex == nil {
            var idx: [String: String] = [:]
            let fm = FileManager.default
            let base = Bundle.main.bundleURL
            if let en = fm.enumerator(at: base, includingPropertiesForKeys: nil,
                                       options: [.skipsHiddenFiles]) {
                for case let u as URL in en {
                    if !u.hasDirectoryPath && !u.lastPathComponent.hasPrefix(".") {
                        idx[u.lastPathComponent] = u.path
                    }
                }
            }
            bundleIndex = idx
        }
        return bundleIndex?[basename]
    }

    static func sha256Hex(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    /// 计算 Bundle 内受监控资源的 SHA-256（hex），key=逻辑路径。对应电脑端 computeFileHashes。
    static func computeInteg() -> [String: String] {
        var out: [String: String] = [:]
        for g in guardedAssets {
            if let path = bundledPath(basename: g.file),
               let data = try? Data(contentsOf: URL(fileURLWithPath: path)) {
                out[g.path] = sha256Hex(data)
            } else {
                out[g.path] = ""
            }
        }
        return out
    }

    /// 读取构建期打进包的完整性清单 {逻辑路径: sha256hex}
    private static func loadManifest() -> [String: String]? {
        guard let p = bundledPath(basename: "integrity_manifest.json"),
              let data = try? Data(contentsOf: URL(fileURLWithPath: p)),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: String] else {
            return nil
        }
        return obj
    }

    /// 本地完整性门禁：Bundle 实际资源 hash 与内置清单逐项比对，任一不符/缺失 → false。
    /// （第一层：本地即拒；真正的权威拦截在服务端 verify 比对 integrity.json。）
    static func integLocalOK() -> Bool {
        guard let manifest = loadManifest() else { return false }
        let actual = computeInteg()
        for g in guardedAssets {
            let expected = manifest[g.path] ?? ""
            let got = actual[g.path] ?? ""
            if expected.isEmpty || got.isEmpty || expected != got { return false }
        }
        return true
    }

    // MARK: - 门禁主入口

    /// gateEnsure：完成后回调主线程，true=放行，false=fail-closed。
    static func gateEnsure(_ completion: @escaping (Bool) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            // 0) 本地完整性先过：Bundle 网页资源被篡改 → 直接 fail-closed
            guard integLocalOK() else {
                DispatchQueue.main.async { completion(false) }
                return
            }
            // 1) 本地票：验签 + 设备 + 到期
            let local = inspect(access: LicenseStore.access())
            let now = Date().timeIntervalSince1970
            if local.ok, let p = local.payload,
               let exp = p["exp"] as? Double,
               exp - now > localGraceSeconds {
                DispatchQueue.main.async { completion(true) }
                return
            }
            // 2) 联网续验（上报 integ；code:1 已在内部清许可，网络异常不清）
            LicenseClient.renewVerify { renewed, _ in
                if renewed {
                    DispatchQueue.main.async { completion(true) }
                    return
                }
                // 3) 弱网宽限：本地票仍未过期 → 放行
                DispatchQueue.main.async { completion(local.ok && LicenseGate.inspect(access: LicenseStore.access()).ok) }
            }
        }
    }
}

