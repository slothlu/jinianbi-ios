import UIKit
import WebKit

/// 主界面：内置浏览器 + 银行页面脚本自动注入
final class ViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler {

    private var webView: WKWebView!
    private let urlField = UITextField()
    private let goButton = UIButton(type: .system)

    private static let injectFiles: [String] = [
        "web/bridge_ios.js",
        "web/banks/BankMatch.js",
        "web/banks/sx_common.js",
        "web/banks/sx_branch_finder.js",
        "web/banks/sx_abc.js",
        "web/banks/sx_boc.js",
        "web/banks/sx_ccb.js",
        "web/banks/sx_icbc.js",
        "web/banks/sx_psbc.js",
        "web/content.js",
        "web/mobile_touch_patch.js"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "路面纪念钞币科技"

        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "SXBridge")
        config.allowsInlineMediaPlayback = true

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        // 与桌面扩展适配的页面版本保持一致
        webView.customUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)

        urlField.borderStyle = .roundedRect
        urlField.placeholder = "输入网址，如 https://..."
        urlField.keyboardType = .URL
        urlField.autocapitalizationType = .none
        urlField.autocorrectionType = .no
        urlField.returnKeyType = .go
        urlField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(urlField)

        goButton.setTitle("前往", for: .normal)
        goButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(goButton)

        // 底部操作栏
        let homeBtn = makeBottomButton("主页", action: #selector(goHome))
        let refreshBtn = makeBottomButton("刷新", action: #selector(refreshPage))
        let settingsBtn = makeBottomButton("设置", action: #selector(openSettings))
        let bar = UIStackView(arrangedSubviews: [homeBtn, refreshBtn, settingsBtn])
        bar.axis = .horizontal
        bar.distribution = .fillEqually
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        NSLayoutConstraint.activate([
            urlField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            urlField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            goButton.leadingAnchor.constraint(equalTo: urlField.trailingAnchor, constant: 8),
            goButton.centerYAnchor.constraint(equalTo: urlField.centerYAnchor),
            goButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            goButton.widthAnchor.constraint(equalToConstant: 52),

            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bar.heightAnchor.constraint(equalToConstant: 44),

            webView.topAnchor.constraint(equalTo: urlField.bottomAnchor, constant: 8),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: bar.topAnchor, constant: -4)
        ])

        goButton.addTarget(self, action: #selector(navigate), for: .touchUpInside)
        urlField.delegate = self

        loadHome()
    }

    private func makeBottomButton(_ title: String, action: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(title, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 15, weight: .medium)
        b.addTarget(self, action: action, for: .touchUpInside)
        return b
    }

    @objc private func goHome() { loadHome() }

    @objc private func refreshPage() { webView.reload() }

    @objc private func openSettings() {
        let vc = SettingsController()
        vc.onPersonsChanged = { [weak self] in
            self?.webView.evaluateJavaScript(
                "window.__sxFirePersonsChanged&&window.__sxFirePersonsChanged()", completionHandler: nil)
        }
        navigationController?.pushViewController(vc, animated: true)
    }

    private func loadHome() {
        guard let path = Bundle.main.path(forResource: "home", ofType: "html", inDirectory: "web") else { return }
        webView.loadFileURL(URL(fileURLWithPath: path), allowingReadAccessTo: Bundle.main.bundleURL)
    }

    @objc private func navigate() {
        guard var u = urlField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !u.isEmpty else { return }
        if !u.hasPrefix("http://") && !u.hasPrefix("https://") { u = "https://" + u }
        if let url = URL(string: u) { webView.load(URLRequest(url: url)) }
        urlField.resignFirstResponder()
    }

    // MARK: - WKNavigationDelegate

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard let url = webView.url?.absoluteString else { return }
        if url.hasPrefix("http://") || url.hasPrefix("https://") {
            injectScripts(into: webView)
        }
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        // 所有链接都在 App 内打开
        decisionHandler(.allow)
    }

    // MARK: - 脚本注入

    private func injectScripts(into view: WKWebView) {
        var sb = "(function(){if(window.__SX_INJECTED__)return;window.__SX_INJECTED__=true;"
        for f in Self.injectFiles {
            sb += readAsset(f) + "\n"
        }
        sb += "})();"
        view.evaluateJavaScript(sb, completionHandler: nil)
    }

    private func readAsset(_ path: String) -> String {
        guard let url = Bundle.main.url(forResource: path, withExtension: nil) else { return "" }
        return (try? String(contentsOf: url, encoding: .utf8)) ?? ""
    }

    // MARK: - WKScriptMessageHandler（JS → 原生）

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard message.name == "SXBridge",
              let body = message.body as? [String: Any],
              let id = body["id"] as? String,
              let action = body["action"] as? String else { return }
        let payload = body["payload"] as? [String: Any] ?? [:]

        switch action {
        case "storageGet":
            resolve(id, value: ["userSettings": PersonStore.getPersonsJson()])
        case "storageSet":
            if let v = payload["userSettings"] as? String {
                PersonStore.savePersonsJson(v)
            }
            resolve(id, value: nil)
        case "openSettings":
            DispatchQueue.main.async { [weak self] in self?.openSettings() }
            resolve(id, value: nil)
        case "ocr":
            guard let data = try? JSONSerialization.data(withJSONObject: payload),
                  let json = String(data: data, encoding: .utf8) else {
                resolve(id, value: ["error": "OCR参数序列化失败"]); return
            }
            performOCR(bodyJson: json) { [weak self] result in
                self?.resolve(id, value: result)
            }
        default:
            resolve(id, value: nil)
        }
    }

    /// 原生回传结果给页面（自动转成 JS 字面量）
    private func resolve(_ id: String, value: Any?) {
        var js: String
        if let value = value,
           let data = try? JSONSerialization.data(withJSONObject: value),
           let str = String(data: data, encoding: .utf8) {
            js = "window.__sxBridgeResolve&&window.__sxBridgeResolve('\(id)',\(str))"
        } else {
            js = "window.__sxBridgeResolve&&window.__sxBridgeResolve('\(id)','null')"
        }
        DispatchQueue.main.async { [weak self] in
            self?.webView.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    /// OCR 识别：原生转发到 ocr.qora.top，绕开页面跨域限制
    private func performOCR(bodyJson: String, completion: @escaping (Any?) -> Void) {
        guard let url = URL(string: "https://ocr.qora.top/ocr") else {
            completion(["error": "OCR地址无效"]); return
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = bodyJson.data(using: .utf8)

        URLSession.shared.dataTask(with: req) { data, _, error in
            if let error = error {
                completion(["error": error.localizedDescription])
                return
            }
            guard let data = data,
                  let str = String(data: data, encoding: .utf8) else {
                completion(["error": "OCR无响应"]); return
            }
            if let obj = try? JSONSerialization.jsonObject(with: data) {
                completion(obj)
            } else {
                completion(["raw": str])
            }
        }.resume()
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        navigate()
        return true
    }
}
